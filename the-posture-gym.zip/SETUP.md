# The Posture Gym - Production Setup & Deployment Manual

Welcome to **The Posture Gym** Full-Stack Management System! This application consists of a high-performance, premium client-facing website and a secure Admin CRM panel.

Below is the structured guide to configure, run, and scale your application to production.

---

## 🔐 Administrative Credentials (Local / Eval)

The administrative database is pre-seeded on startup with the following credentials:
* **Admin Email:** `admin@theposture.com`
* **Admin Password:** `admin123`

*Note: These credentials are saved securely using salted hashes (`bcryptjs`) inside your local `./data/db.json` database.*

---

## 🌐 Official WhatsApp Business Platform Integration

To transition from Sandbox/Simulation Mode to live production messaging, configure the Meta Business Suite:

1. **Create a Meta Developer Account:**
   * Visit [developers.facebook.com](https://developers.facebook.com/) and register as a developer.
   * Click **Create App** and select **Business** or **Other**.

2. **Add WhatsApp Product:**
   * Locate the **WhatsApp** product in your App Dashboard and click **Set Up**.
   * Link your developer app to your Facebook Business Manager Account.

3. **Retrieve Credentials:**
   * Under **WhatsApp > API Setup**, copy:
     * **Temporary/Permanent Access Token** (Bearer token).
     * **Phone Number ID** (e.g., `10485934584`).

4. **Register a Message Template:**
   * Go to your **WhatsApp Manager** (via Business Suite) and navigate to **Message Templates**.
   * Create a new template named `membership_renewal_reminder` (or custom) with the following structure:
     > Hi **{{1}}**! 👋
     > Just a quick heads-up — your gym membership is set to expire in 3 days (on **{{2}}**).
     > We'd hate for you to lose momentum on your fitness goals!
     > Renew now to keep uninterrupted access to the gym, classes, and equipment.
     > It takes less than 2 minutes.
     > See you at the gym! 💪
   * Wait for Meta's automated approval (typically takes &lt; 2 minutes).

5. **Configure inside Admin Panel:**
   * Log in to your Admin Portal.
   * Go to **Club Settings** and input:
     * Permanent Access Token
     * Phone Number ID
     * Registered Template Name (e.g., `membership_renewal_reminder`)
   * Click **Save Configuration**. The system will now route all automatic & manual reminders through the Meta Graph API!

---

## 🗄️ Relational Database & Prisma Schema (Production PostgreSQL)

The development environment utilizes a highly reliable local JSON file database (`./data/db.json`) that supports transactional reads/writes out of the box with zero compilation or external driver dependencies.

To migrate to a relational **PostgreSQL** (on Supabase, Neon, or Cloud SQL) using **Prisma ORM** as requested for production, use the following schema mapping:

### 1. Prisma Production Schema (`prisma/schema.prisma`)
```prisma
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-id"
}

model User {
  id           String   @id @default(uuid())
  email        String   @unique
  passwordHash String
  fullName     String
  createdAt    DateTime @default(now())
}

model Member {
  id                    String    @id
  fullName              String
  phone                 String
  email                 String?
  gender                String    @default("Male")
  dob                   String?
  address               String?
  emergencyContact      String?
  membershipPlan        String
  joiningDate           String
  membershipExpiryDate  String
  paymentStatus         String    @default("Unpaid") // Paid, Partial, Unpaid
  amountPaid            Float     @default(0.0)
  remainingBalance      Float     @default(0.0)
  notes                 String?
  photoUrl              String?
  createdAt             DateTime  @default(now())
  payments              Payment[]
  reminders             Reminder[]
}

model Payment {
  id         String   @id @default(uuid())
  memberId   String
  member     Member   @relation(fields: [memberId], references: [id], onDelete: Cascade)
  memberName String
  amount     Float
  date       String
  status     String
  receiptNo  String   @unique
  plan       String
  notes      String?
  createdAt  DateTime @default(now())
}

model Reminder {
  id           String   @id @default(uuid())
  memberId     String
  member       Member   @relation(fields: [memberId], references: [id], onDelete: Cascade)
  memberName   String
  phone        String
  expiryDate   String
  status       String   // Success, Failed
  timestamp    DateTime @default(now())
  attemptCount Int      @default(1)
  error        String?
}

model Notification {
  id         String   @id @default(uuid())
  type       String   // success, error, info
  message    String
  memberName String
  expiryDate String
  status     String
  timestamp  DateTime @default(now())
  read       Boolean  @default(false)
}

model Settings {
  id                   Int    @id @default(1)
  gymName              String @default("The Posture Gym")
  address              String
  phone                String
  email                String
  whatsappToken        String?
  whatsappPhoneId      String?
  whatsappTemplateName String @default("membership_renewal_reminder")
  theme                String @default("dark")
}
```

---

## 🚀 Deployment Commands

### Local Development
To boot up the full-stack server locally (runs on Port 3000):
```bash
npm run dev
```

### Production Build
To compile static bundles and bundle the Express backend into `dist/server.cjs`:
```bash
npm run build
```

### Production Execution
To run the pre-compiled full-stack app in your container or VPS:
```bash
npm run start
```
