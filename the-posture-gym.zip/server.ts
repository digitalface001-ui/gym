import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import { readDb, writeDb } from "./src/server/db";
import { sendWhatsAppReminder } from "./src/server/whatsapp";
import { Member, Payment, ReminderLog, AdminNotification, GymSettings } from "./src/types";

dotenv.config();

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "the-posture-gym-jwt-secret-key-123456";

app.use(express.json());

// Helper to authenticate JWT
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: "Access token is required. Please login." });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ error: "Invalid or expired session. Please login again." });
    }
    req.user = user;
    next();
  });
};

// ==========================================
// AUTHENTICATION ENDPOINTS
// ==========================================

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required" });
  }

  const db = readDb();
  const user = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: "Invalid email or password" });
  }

  const token = jwt.sign({ id: user.id, email: user.email, fullName: user.fullName }, JWT_SECRET, { expiresIn: "24h" });
  res.json({
    token,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName
    }
  });
});

app.get("/api/auth/me", authenticateToken, (req: any, res) => {
  res.json({ user: req.user });
});

// ==========================================
// MEMBERS CRUD ENDPOINTS
// ==========================================

app.get("/api/members", authenticateToken, (req, res) => {
  const db = readDb();
  res.json(db.members);
});

app.get("/api/members/:id", authenticateToken, (req, res) => {
  const db = readDb();
  const member = db.members.find(m => m.id === req.params.id);
  if (!member) {
    return res.status(404).json({ error: "Member not found" });
  }
  res.json(member);
});

app.post("/api/members", authenticateToken, (req, res) => {
  const db = readDb();
  const {
    fullName, phone, email, gender, dob, address, emergencyContact,
    membershipPlan, joiningDate, membershipExpiryDate, paymentStatus,
    amountPaid, remainingBalance, notes, photoUrl
  } = req.body;

  if (!fullName || !phone) {
    return res.status(400).json({ error: "Full Name and Phone Number are required" });
  }

  // Generate unique Member ID
  const lastMember = db.members.reduce((max, m) => {
    const num = parseInt(m.id.split('-')[1]);
    return num > max ? num : max;
  }, 1000);
  const nextId = `MEM-${lastMember + 1}`;

  const newMember: Member = {
    id: nextId,
    fullName,
    phone,
    email: email || "",
    gender: gender || "Male",
    dob: dob || "",
    address: address || "",
    emergencyContact: emergencyContact || "",
    membershipPlan: membershipPlan || "Monthly Elite",
    joiningDate: joiningDate || new Date().toISOString().split('T')[0],
    membershipExpiryDate: membershipExpiryDate || new Date().toISOString().split('T')[0],
    paymentStatus: paymentStatus || "Unpaid",
    amountPaid: Number(amountPaid) || 0,
    remainingBalance: Number(remainingBalance) || 0,
    notes: notes || "",
    photoUrl: photoUrl || ""
  };

  db.members.unshift(newMember);

  // If a payment is recorded, add a transaction record
  if (newMember.amountPaid > 0) {
    const payId = `PAY-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newPayment: Payment = {
      id: payId,
      memberId: nextId,
      memberName: fullName,
      amount: newMember.amountPaid,
      date: newMember.joiningDate,
      status: newMember.paymentStatus,
      receiptNo: `REC-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000 + 10000)}`,
      plan: newMember.membershipPlan,
      notes: "Initial membership payment"
    };
    db.payments.unshift(newPayment);
  }

  writeDb(db);
  res.status(201).json(newMember);
});

app.put("/api/members/:id", authenticateToken, (req, res) => {
  const db = readDb();
  const idx = db.members.findIndex(m => m.id === req.params.id);
  if (idx === -1) {
    return res.status(404).json({ error: "Member not found" });
  }

  const existingMember = db.members[idx];
  const updatedData = req.body;

  // Update logic
  const updatedMember: Member = {
    ...existingMember,
    ...updatedData,
    id: existingMember.id // lock ID
  };

  db.members[idx] = updatedMember;
  writeDb(db);
  res.json(updatedMember);
});

app.delete("/api/members/:id", authenticateToken, (req, res) => {
  const db = readDb();
  const index = db.members.findIndex(m => m.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Member not found" });
  }

  db.members.splice(index, 1);
  writeDb(db);
  res.json({ success: true, message: "Member removed successfully" });
});

// ==========================================
// PAYMENTS LEDGER ENDPOINTS
// ==========================================

app.get("/api/payments", authenticateToken, (req, res) => {
  const db = readDb();
  res.json(db.payments);
});

app.post("/api/payments/record", authenticateToken, (req, res) => {
  const db = readDb();
  const { memberId, amount, status, notes, planName } = req.body;

  if (!memberId || !amount) {
    return res.status(400).json({ error: "Member ID and Amount are required" });
  }

  const memberIdx = db.members.findIndex(m => m.id === memberId);
  if (memberIdx === -1) {
    return res.status(404).json({ error: "Member not found" });
  }

  const member = db.members[memberIdx];
  const payId = `PAY-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  
  const paymentRecord: Payment = {
    id: payId,
    memberId: member.id,
    memberName: member.fullName,
    amount: Number(amount),
    date: new Date().toISOString().split('T')[0],
    status: status || "Paid",
    receiptNo: `REC-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000 + 10000)}`,
    plan: planName || member.membershipPlan,
    notes: notes || "Payment entry recorded by administrator"
  };

  db.payments.unshift(paymentRecord);

  // Update member totals
  member.amountPaid += Number(amount);
  if (member.remainingBalance > 0) {
    member.remainingBalance = Math.max(0, member.remainingBalance - Number(amount));
  }
  if (member.remainingBalance === 0) {
    member.paymentStatus = 'Paid';
  } else {
    member.paymentStatus = 'Partial';
  }

  writeDb(db);
  res.status(201).json(paymentRecord);
});

app.post("/api/payments/renew", authenticateToken, (req, res) => {
  const db = readDb();
  const { memberId, planId, amountPaid, joiningDate, notes } = req.body;

  const memberIdx = db.members.findIndex(m => m.id === memberId);
  if (memberIdx === -1) {
    return res.status(404).json({ error: "Member not found" });
  }

  const plan = db.settings.plans.find(p => p.id === planId);
  if (!plan) {
    return res.status(404).json({ error: "Membership plan not found" });
  }

  const member = db.members[memberIdx];

  // Calculate new expiry date based on plan duration (months)
  const jDate = new Date(joiningDate || new Date().toISOString().split('T')[0]);
  const expDate = new Date(jDate);
  expDate.setMonth(expDate.getMonth() + plan.durationMonths);
  const expiryDateStr = expDate.toISOString().split('T')[0];

  const paidVal = Number(amountPaid) || 0;
  const balance = Math.max(0, plan.price - paidVal);
  let status: 'Paid' | 'Partial' | 'Unpaid' = 'Paid';
  if (paidVal === 0) status = 'Unpaid';
  else if (balance > 0) status = 'Partial';

  // Record payment
  const payId = `PAY-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const paymentRecord: Payment = {
    id: payId,
    memberId: member.id,
    memberName: member.fullName,
    amount: paidVal,
    date: joiningDate || new Date().toISOString().split('T')[0],
    status,
    receiptNo: `REC-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000 + 10000)}`,
    plan: plan.name,
    notes: notes || `Plan Renewal: ${plan.name}`
  };

  db.payments.unshift(paymentRecord);

  // Update member plan, joining, expiry, and dues
  member.membershipPlan = plan.name;
  member.joiningDate = joiningDate || new Date().toISOString().split('T')[0];
  member.membershipExpiryDate = expiryDateStr;
  member.amountPaid = paidVal;
  member.remainingBalance = balance;
  member.paymentStatus = status;

  writeDb(db);
  res.status(200).json({ success: true, member, payment: paymentRecord });
});

// ==========================================
// RENEWAL ALERTS & INTEGRATION
// ==========================================

app.get("/api/reminders", authenticateToken, (req, res) => {
  const db = readDb();
  res.json(db.reminders);
});

app.get("/api/notifications", authenticateToken, (req, res) => {
  const db = readDb();
  res.json(db.notifications);
});

app.put("/api/notifications/mark-read", authenticateToken, (req, res) => {
  const db = readDb();
  db.notifications.forEach(n => n.read = true);
  writeDb(db);
  res.json({ success: true });
});

// Single Manual Send API
app.post("/api/reminders/send-manual", authenticateToken, async (req, res) => {
  const { memberId } = req.body;
  if (!memberId) {
    return res.status(400).json({ error: "Member ID is required" });
  }

  const db = readDb();
  const member = db.members.find(m => m.id === memberId);
  if (!member) {
    return res.status(404).json({ error: "Member not found" });
  }

  const result = await sendWhatsAppReminder(member, member.membershipExpiryDate, db.settings);
  res.json(result);
});

// Automated Job Trigger (to allow admins to test / run any time they click "Run Automation Now")
app.post("/api/reminders/trigger-check", authenticateToken, async (req, res) => {
  const stats = await runDailyAutomatedReminders();
  res.json(stats);
});

// ==========================================
// SETTINGS ENDPOINTS
// ==========================================

app.get("/api/settings", authenticateToken, (req, res) => {
  const db = readDb();
  res.json(db.settings);
});

app.post("/api/settings/save", authenticateToken, (req, res) => {
  const db = readDb();
  db.settings = {
    ...db.settings,
    ...req.body
  };
  writeDb(db);
  res.json({ success: true, settings: db.settings });
});

// ==========================================
// REPORTS & DASHBOARD METRICS
// ==========================================

app.get("/api/reports/dashboard", authenticateToken, (req, res) => {
  const db = readDb();
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  // Helper date calculations
  const date3DaysLater = new Date();
  date3DaysLater.setDate(now.getDate() + 3);
  const date3DaysLaterStr = date3DaysLater.toISOString().split('T')[0];

  const curMonth = now.getMonth();
  const curYear = now.getFullYear();

  let activeCount = 0;
  let expiredCount = 0;
  let expiring3DaysCount = 0;
  let newThisMonthCount = 0;

  db.members.forEach(m => {
    // Check if membership is expired or active
    const expDate = new Date(m.membershipExpiryDate);
    const isExpired = m.membershipExpiryDate < todayStr;
    
    if (isExpired) {
      expiredCount++;
    } else {
      activeCount++;
    }

    // Expiring in exactly 3 days (matching target date strings)
    if (m.membershipExpiryDate === date3DaysLaterStr) {
      expiring3DaysCount++;
    }

    // New member this month
    const joinDate = new Date(m.joiningDate);
    if (joinDate.getMonth() === curMonth && joinDate.getFullYear() === curYear) {
      newThisMonthCount++;
    }
  });

  // Revenue totals
  let todayRevenue = 0;
  let monthlyRevenue = 0;
  let annualRevenue = 0;

  db.payments.forEach(p => {
    const payDate = new Date(p.date);
    if (p.date === todayStr) {
      todayRevenue += p.amount;
    }
    if (payDate.getMonth() === curMonth && payDate.getFullYear() === curYear) {
      monthlyRevenue += p.amount;
    }
    if (payDate.getFullYear() === curYear) {
      annualRevenue += p.amount;
    }
  });

  // Distribution chart data
  const planDistribution: { [key: string]: number } = {};
  db.members.forEach(m => {
    planDistribution[m.membershipPlan] = (planDistribution[m.membershipPlan] || 0) + 1;
  });

  const dashboardStats = {
    totalMembers: db.members.length,
    activeMembers: activeCount,
    expiringIn3Days: expiring3DaysCount,
    expiredMembers: expiredCount,
    todayRevenue,
    monthlyRevenue,
    annualRevenue,
    newMembersThisMonth: newThisMonthCount,
    planDistribution: Object.keys(planDistribution).map(name => ({ name, value: planDistribution[name] })),
    recentPayments: db.payments.slice(0, 5),
    notifications: db.notifications.slice(0, 10)
  };

  res.json(dashboardStats);
});

// ==========================================
// AUTOMATED 9:00 AM RENEWAL REMINDER ENGINE
// ==========================================

async function runDailyAutomatedReminders() {
  console.log("[Scheduler] Running automatic renewal reminder checks...");
  const db = readDb();
  
  // Expiry is in exactly 3 days from now
  const targetDate = new Date();
  targetDate.setDate(targetDate.getDate() + 3);
  const targetDateStr = targetDate.toISOString().split('T')[0];

  const expiringMembers = db.members.filter(m => m.membershipExpiryDate === targetDateStr);
  console.log(`[Scheduler] Found ${expiringMembers.length} members expiring on ${targetDateStr}`);

  let sentCount = 0;
  let failCount = 0;

  for (const member of expiringMembers) {
    // Avoid double reminder sends for the same date & member today
    const alreadySentToday = db.reminders.some(
      r => r.memberId === member.id && 
           r.expiryDate === targetDateStr && 
           r.status === 'Success' &&
           r.timestamp.startsWith(new Date().toISOString().split('T')[0])
    );

    if (alreadySentToday) {
      console.log(`[Scheduler] Reminder already sent successfully for ${member.fullName} today.`);
      continue;
    }

    const result = await sendWhatsAppReminder(member, targetDateStr, db.settings);
    if (result.success) sentCount++;
    else failCount++;
  }

  return {
    runAt: new Date().toISOString(),
    checkedExpiryDate: targetDateStr,
    totalChecked: expiringMembers.length,
    successfulReminders: sentCount,
    failedReminders: failCount
  };
}

// Background scheduler interval (Every 1 hour, checks if it is 9:00 AM)
// Also triggers on application boot to ensure immediate scheduling capabilities.
let lastRunDayStr = "";
setInterval(async () => {
  const now = new Date();
  const currentDayStr = now.toISOString().split('T')[0];
  const currentHour = now.getHours();

  // If it's 9 AM and we haven't run it yet today
  if (currentHour === 9 && lastRunDayStr !== currentDayStr) {
    lastRunDayStr = currentDayStr;
    try {
      await runDailyAutomatedReminders();
    } catch (e) {
      console.error("[Scheduler] Error running automated reminders:", e);
    }
  }
}, 1000 * 60 * 30); // check every 30 mins

// Trigger on server boot after 10 seconds to process pending ones
setTimeout(async () => {
  try {
    await runDailyAutomatedReminders();
  } catch (e) {
    console.error("[Scheduler Startup] Error running startup reminders check:", e);
  }
}, 10000);

// ==========================================
// VITE DEV SERVER MIDDLEWARE AND PRODUCTION
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
