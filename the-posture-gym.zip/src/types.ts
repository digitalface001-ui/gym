export interface Member {
  id: string; // Auto-generated e.g. MEM-1001
  fullName: string;
  phone: string;
  email: string;
  gender: string;
  dob: string;
  address: string;
  emergencyContact: string;
  membershipPlan: string;
  joiningDate: string;
  membershipExpiryDate: string;
  paymentStatus: 'Paid' | 'Partial' | 'Unpaid';
  amountPaid: number;
  remainingBalance: number;
  notes: string;
  photoUrl?: string;
}

export interface Payment {
  id: string;
  memberId: string;
  memberName: string;
  amount: number;
  date: string;
  status: 'Paid' | 'Partial' | 'Unpaid';
  receiptNo: string;
  plan: string;
  notes: string;
}

export interface ReminderLog {
  id: string;
  memberId: string;
  memberName: string;
  phone: string;
  expiryDate: string;
  status: 'Success' | 'Failed';
  timestamp: string;
  attemptCount: number;
  error?: string;
}

export interface AdminNotification {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
  memberName: string;
  expiryDate: string;
  status: string;
  timestamp: string;
  read: boolean;
}

export interface GymSettings {
  gymName: string;
  address: string;
  phone: string;
  email: string;
  whatsappToken: string;
  whatsappPhoneId: string;
  whatsappTemplateName: string;
  emailServer: string;
  emailUser: string;
  logoUrl?: string;
  theme: 'dark' | 'light';
  plans: {
    id: string;
    name: string;
    durationMonths: number;
    price: number;
    features: string[];
  }[];
}

export interface DashboardStats {
  totalMembers: number;
  activeMembers: number;
  expiringIn3Days: number;
  expiredMembers: number;
  todayRevenue: number;
  monthlyRevenue: number;
  annualRevenue: number;
  newMembersThisMonth: number;
}
