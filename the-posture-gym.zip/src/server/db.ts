import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { Member, Payment, ReminderLog, AdminNotification, GymSettings } from '../types';

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'db.json');

interface DatabaseSchema {
  users: { id: string; email: string; passwordHash: string; fullName: string }[];
  members: Member[];
  payments: Payment[];
  reminders: ReminderLog[];
  notifications: AdminNotification[];
  settings: GymSettings;
}

const DEFAULT_SETTINGS: GymSettings = {
  gymName: 'The Posture Gym',
  address: '303, 7th Main, 3rd Cross Road, Near Mysore Donne Biryani, Saraswathipuram, Mysuru, Karnataka 570009',
  phone: '+91 97316 77316',
  email: 'info@theposturegym.in',
  whatsappToken: '',
  whatsappPhoneId: '',
  whatsappTemplateName: 'membership_renewal_reminder',
  emailServer: 'smtp.gmail.com',
  emailUser: 'notifications@theposturegym.in',
  theme: 'dark',
  plans: [
    {
      id: 'plan_monthly',
      name: 'Monthly Elite',
      durationMonths: 1,
      price: 2500,
      features: ['Access to Strength & Cardio', 'Locker & Washroom Access', '1 Free General Trainer Session', 'Nutrition Guidance']
    },
    {
      id: 'plan_quarterly',
      name: 'Quarterly Pro',
      durationMonths: 3,
      price: 6500,
      features: ['Access to Strength & Cardio', 'Locker & Washroom Access', 'Nutrition Guidance', 'Personalized Workout Plan', '1 Guest Pass per month']
    },
    {
      id: 'plan_halfyearly',
      name: 'Half-Yearly Power',
      durationMonths: 6,
      price: 11000,
      features: ['Access to Strength & Cardio', 'Locker & Washroom Access', 'Nutrition Guidance', 'Personalized Workout Plan', 'Body Composition Analysis', 'Monthly Progress Reviews']
    },
    {
      id: 'plan_annual',
      name: 'Annual Legend',
      durationMonths: 12,
      price: 18000,
      features: ['24/7 Access to Gym & Turf', 'Dedicated Locker', 'Unlimited Nutrition Counseling', '2 Personal Trainer Sessions/Month', 'Free Club Merchandise', 'VIP Guest Access']
    }
  ]
};

function ensureDbExists() {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync('admin123', salt);
  const tejasPasswordHash = bcrypt.hashSync('123456', salt);

  if (!fs.existsSync(DB_FILE)) {
    const initialDb: DatabaseSchema = {
      users: [
        {
          id: 'usr_1',
          email: 'admin@theposture.com',
          passwordHash,
          fullName: 'Gym Admin'
        },
        {
          id: 'usr_2',
          email: 'tejashn12@gmail.com',
          passwordHash: tejasPasswordHash,
          fullName: 'Gym Admin'
        }
      ],
      members: [
        {
          id: 'MEM-1001',
          fullName: 'Rahul Sharma',
          phone: '+91 97316 77316', // Using contact phone for testing
          email: 'rahul.sharma@gmail.com',
          gender: 'Male',
          dob: '1995-04-12',
          address: 'Kuempunagar, Mysuru',
          emergencyContact: 'Amit Sharma (+91 98765 43210)',
          membershipPlan: 'Monthly Elite',
          joiningDate: '2026-06-24',
          membershipExpiryDate: '2026-07-24', // Expiring in exactly 3 days from 2026-07-21!
          paymentStatus: 'Paid',
          amountPaid: 2500,
          remainingBalance: 0,
          notes: 'Goal is weight training and posture correction.',
          photoUrl: ''
        },
        {
          id: 'MEM-1002',
          fullName: 'Priya Gowda',
          phone: '+91 91234 56789',
          email: 'priya.gowda@outlook.com',
          gender: 'Female',
          dob: '1998-08-20',
          address: 'Saraswathipuram, Mysuru',
          emergencyContact: 'Shanthala Gowda (+91 91234 56780)',
          membershipPlan: 'Quarterly Pro',
          joiningDate: '2026-05-10',
          membershipExpiryDate: '2026-08-10', // Active
          paymentStatus: 'Paid',
          amountPaid: 6500,
          remainingBalance: 0,
          notes: 'Focuses on functional fitness and yoga.',
          photoUrl: ''
        },
        {
          id: 'MEM-1003',
          fullName: 'Karthik Kumar',
          phone: '+91 99887 76655',
          email: 'karthik.k@yahoo.com',
          gender: 'Male',
          dob: '1992-11-05',
          address: 'Gokulam, Mysuru',
          emergencyContact: 'Vijay Kumar (+91 99887 76650)',
          membershipPlan: 'Annual Legend',
          joiningDate: '2025-07-15',
          membershipExpiryDate: '2026-07-15', // Already Expired
          paymentStatus: 'Partial',
          amountPaid: 15000,
          remainingBalance: 3000,
          notes: 'Needs renewal. Has pending balance.',
          photoUrl: ''
        },
        {
          id: 'MEM-1004',
          fullName: 'Ananya Rao',
          phone: '+91 88776 65544',
          email: 'ananya.rao@gmail.com',
          gender: 'Female',
          dob: '2001-02-14',
          address: 'Jayalakshmipuram, Mysuru',
          emergencyContact: 'S. Rao (+91 88776 65540)',
          membershipPlan: 'Half-Yearly Power',
          joiningDate: '2026-07-01',
          membershipExpiryDate: '2027-01-01', // Active
          paymentStatus: 'Paid',
          amountPaid: 11000,
          remainingBalance: 0,
          notes: 'Wants to improve posture and overall mobility.',
          photoUrl: ''
        }
      ],
      payments: [
        {
          id: 'PAY-1001',
          memberId: 'MEM-1001',
          memberName: 'Rahul Sharma',
          amount: 2500,
          date: '2026-06-24',
          status: 'Paid',
          receiptNo: 'REC-2026-0001',
          plan: 'Monthly Elite',
          notes: 'Initial Plan payment.'
        },
        {
          id: 'PAY-1002',
          memberId: 'MEM-1002',
          memberName: 'Priya Gowda',
          amount: 6500,
          date: '2026-05-10',
          status: 'Paid',
          receiptNo: 'REC-2026-0002',
          plan: 'Quarterly Pro',
          notes: 'Full payment.'
        },
        {
          id: 'PAY-1003',
          memberId: 'MEM-1003',
          memberName: 'Karthik Kumar',
          amount: 15000,
          date: '2025-07-15',
          status: 'Partial',
          receiptNo: 'REC-2025-0012',
          plan: 'Annual Legend',
          notes: 'Partial payment. 3000 dues outstanding.'
        },
        {
          id: 'PAY-1004',
          memberId: 'MEM-1004',
          memberName: 'Ananya Rao',
          amount: 11000,
          date: '2026-07-01',
          status: 'Paid',
          receiptNo: 'REC-2026-0003',
          plan: 'Half-Yearly Power',
          notes: 'Full payment.'
        }
      ],
      reminders: [],
      notifications: [
        {
          id: 'notif_1',
          type: 'info',
          message: 'Welcome to The Posture Gym Management System!',
          memberName: 'System',
          expiryDate: '',
          status: 'Info',
          timestamp: '2026-07-21T09:00:00Z',
          read: false
        }
      ],
      settings: DEFAULT_SETTINGS
    };

    fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), 'utf-8');
  } else {
    // Dynamically verify and inject / update tejas admin if file already exists
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      const db = JSON.parse(data) as DatabaseSchema;
      const tejasEmail = 'tejashn12@gmail.com';
      const tejasIdx = db.users.findIndex(u => u.email.toLowerCase() === tejasEmail.toLowerCase());

      if (tejasIdx === -1) {
        db.users.push({
          id: `usr_${db.users.length + 1}`,
          email: tejasEmail,
          passwordHash: tejasPasswordHash,
          fullName: 'Gym Admin'
        });
        fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
      } else {
        // Ensure its password hash is synchronized to "123456"
        if (!bcrypt.compareSync('123456', db.users[tejasIdx].passwordHash)) {
          db.users[tejasIdx].passwordHash = tejasPasswordHash;
          fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
        }
      }
    } catch (e) {
      console.error("Error updating admin user dynamically", e);
    }
  }
}

export function readDb(): DatabaseSchema {
  ensureDbExists();
  const data = fs.readFileSync(DB_FILE, 'utf-8');
  return JSON.parse(data);
}

export function writeDb(db: DatabaseSchema) {
  ensureDbExists();
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
}
