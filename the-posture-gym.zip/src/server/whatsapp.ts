import { Member, GymSettings, ReminderLog, AdminNotification } from '../types';
import { readDb, writeDb } from './db';

/**
 * Sends a WhatsApp renewal reminder using the official WhatsApp Business Platform Cloud API.
 * If credentials are not configured, it will simulate the send and log it cleanly.
 */
export async function sendWhatsAppReminder(
  member: Member,
  expiryDateStr: string,
  settings: GymSettings
): Promise<{ success: boolean; error?: string }> {
  const messageText = `Hi ${member.fullName}! 👋

Just a quick heads-up — your gym membership is set to expire in 3 days (on ${expiryDateStr}).

We'd hate for you to lose momentum on your fitness goals!

Renew now to keep uninterrupted access to the gym, classes, and equipment.

It takes less than 2 minutes.

See you at the gym! 💪`;

  const phone = member.phone.replace(/[^0-9+]/g, ''); // clean phone number
  
  // Create a base log entry
  const logId = `REM-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const timestamp = new Date().toISOString();

  // If credentials are configured, try to send a real message
  if (settings.whatsappToken && settings.whatsappPhoneId) {
    try {
      const url = `https://graph.facebook.com/v17.0/${settings.whatsappPhoneId}/messages`;
      
      // We use the template-based message for official Cloud API compliance
      const body = {
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: phone,
        type: "template",
        template: {
          name: settings.whatsappTemplateName || "membership_renewal_reminder",
          language: {
            code: "en"
          },
          components: [
            {
              type: "body",
              parameters: [
                {
                  type: "text",
                  text: member.fullName
                },
                {
                  type: "text",
                  text: expiryDateStr
                }
              ]
            }
          ]
        }
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${settings.whatsappToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      const data = await response.json() as any;

      if (response.ok) {
        logReminderAttempt({
          id: logId,
          memberId: member.id,
          memberName: member.fullName,
          phone: member.phone,
          expiryDate: expiryDateStr,
          status: 'Success',
          timestamp,
          attemptCount: 1
        });

        createNotification({
          id: `notif-${Date.now()}`,
          type: 'success',
          message: `Renewal reminder sent to ${member.fullName}. Membership expires on ${expiryDateStr}.`,
          memberName: member.fullName,
          expiryDate: expiryDateStr,
          status: 'Success',
          timestamp,
          read: false
        });

        return { success: true };
      } else {
        const errMsg = data?.error?.message || 'Unknown WhatsApp API error';
        
        logReminderAttempt({
          id: logId,
          memberId: member.id,
          memberName: member.fullName,
          phone: member.phone,
          expiryDate: expiryDateStr,
          status: 'Failed',
          timestamp,
          attemptCount: 1,
          error: errMsg
        });

        createNotification({
          id: `notif-${Date.now()}`,
          type: 'error',
          message: `Failed to send reminder to ${member.fullName}: ${errMsg}`,
          memberName: member.fullName,
          expiryDate: expiryDateStr,
          status: 'Failed',
          timestamp,
          read: false
        });

        return { success: false, error: errMsg };
      }
    } catch (err: any) {
      const errMsg = err?.message || 'Network error';
      
      logReminderAttempt({
        id: logId,
        memberId: member.id,
        memberName: member.fullName,
        phone: member.phone,
        expiryDate: expiryDateStr,
        status: 'Failed',
        timestamp,
        attemptCount: 1,
        error: errMsg
      });

      createNotification({
        id: `notif-${Date.now()}`,
        type: 'error',
        message: `Failed to send reminder to ${member.fullName}: ${errMsg}`,
        memberName: member.fullName,
        expiryDate: expiryDateStr,
        status: 'Failed',
        timestamp,
        read: false
      });

      return { success: false, error: errMsg };
    }
  } else {
    // Sandbox / Simulation Mode (no credentials provided)
    // Create the success log for interactive preview
    logReminderAttempt({
      id: logId,
      memberId: member.id,
      memberName: member.fullName,
      phone: member.phone,
      expiryDate: expiryDateStr,
      status: 'Success',
      timestamp,
      attemptCount: 1,
      error: 'Simulated (Configure WhatsApp API credentials in Settings for real delivery)'
    });

    createNotification({
      id: `notif-${Date.now()}`,
      type: 'success',
      message: `Renewal reminder sent to ${member.fullName} [Simulation Mode]. Membership expires on ${expiryDateStr}.`,
      memberName: member.fullName,
      expiryDate: expiryDateStr,
      status: 'Success',
      timestamp,
      read: false
    });

    console.log(`[WhatsApp Simulation] To: ${phone}\nMessage:\n${messageText}`);
    return { success: true };
  }
}

function logReminderAttempt(log: ReminderLog) {
  const db = readDb();
  db.reminders.unshift(log);
  writeDb(db);
}

function createNotification(notif: AdminNotification) {
  const db = readDb();
  db.notifications.unshift(notif);
  writeDb(db);
}
