import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Dumbbell, Shield, Award, Users, MapPin, Phone, Mail, 
  ChevronRight, Calculator, Check, ArrowRight, Instagram, 
  Star, Heart, Flame, Sparkles, Clock, Compass
} from 'lucide-react';

interface PublicWebsiteProps {
  onJoinNow: (planName: string) => void;
  onAdminLoginClick: () => void;
}

export default function PublicWebsite({ onJoinNow, onAdminLoginClick }: PublicWebsiteProps) {
  // BMI State
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmiResult, setBmiResult] = useState<number | null>(null);
  const [bmiCategory, setBmiCategory] = useState('');
  const [bmiAdvice, setBmiAdvice] = useState('');

  // Contact Form State
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Calculate BMI
  const handleCalculateBMI = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100; // convert cm to meters
    if (w > 0 && h > 0) {
      const bmi = parseFloat((w / (h * h)).toFixed(1));
      setBmiResult(bmi);

      let cat = '';
      let advice = '';
      if (bmi < 18.5) {
        cat = 'Underweight';
        advice = 'Focus on nutrient-dense calorie surplus and guided strength training at The Posture Gym to safely build lean muscle.';
      } else if (bmi >= 18.5 && bmi < 24.9) {
        cat = 'Normal Weight';
        advice = 'Excellent! Maintain your balance with our customized posture alignment and strength maintenance programs.';
      } else if (bmi >= 25 && bmi < 29.9) {
        cat = 'Overweight';
        advice = 'Incorporate active high-intensity functional training (HIFT) combined with posture correction to build endurance and burn calories.';
      } else {
        cat = 'Obese';
        advice = 'We recommend structured, low-impact strength training and high-density cardio under professional supervision to safeguard joints while shedding fat.';
      }
      setBmiCategory(cat);
      setBmiAdvice(advice);
    }
  };

  // Contact Submit
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (contactName && contactPhone) {
      setContactSuccess(true);
      setTimeout(() => {
        setContactSuccess(false);
        setContactName('');
        setContactPhone('');
        setContactMessage('');
      }, 4000);
    }
  };

  // Static Data
  const plans = [
    {
      name: 'Monthly Elite',
      price: '₹2,500',
      period: 'Month',
      popular: false,
      features: [
        'Access to Strength & Cardio Areas',
        'State-of-the-art Posture Assessment',
        'Locker & Washroom Access',
        '1 Free General Trainer Session',
        'Basic Nutrition Guidance'
      ]
    },
    {
      name: 'Quarterly Pro',
      price: '₹6,500',
      period: '3 Months',
      popular: true,
      features: [
        'Access to Strength & Cardio Areas',
        'State-of-the-art Posture Assessment',
        'Locker & Washroom Access',
        'Personalized Workout Routine',
        'Nutrition Guidance & Goal Mapping',
        '1 Free Personal Training Demo'
      ]
    },
    {
      name: 'Half-Yearly Power',
      price: '₹11,000',
      period: '6 Months',
      popular: false,
      features: [
        'All Quarterly Pro features included',
        'Detailed Posture Correction Program',
        'Bi-weekly Body Composition Checks',
        'Priority Locker Booking',
        'Dedicated Coach Consultation'
      ]
    },
    {
      name: 'Annual Legend',
      price: '₹18,000',
      period: '12 Months',
      popular: false,
      features: [
        'Unlimited 24/7 Access to Facility',
        'Dedicated Locker & Premium Towels',
        'Continuous Posture Correction Tracker',
        'Unlimited Nutrition Counseling',
        '2 Personal Trainer Sessions/Month',
        'Official Posture Club T-Shirt'
      ]
    }
  ];

  const trainers = [
    {
      name: 'Vikram Sinha',
      role: 'Head Posture Coach & Strength Expert',
      exp: '10+ Years Experience',
      cert: 'Certified Posture Specialist, Kinesiology Degree',
      image: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=500&q=80'
    },
    {
      name: 'Rohan Deshmukh',
      role: 'Elite Functional Training & Conditioning',
      exp: '8 Years Experience',
      cert: 'ACE Certified Personal Trainer, Strength Conditioning Specialist',
      image: 'https://images.unsplash.com/photo-1605296867304-46d5465a25f1?auto=format&fit=crop&w=500&q=80'
    },
    {
      name: 'Anjali Sharma',
      role: 'Mobility, Calisthenics & Posture Therapist',
      exp: '6 Years Experience',
      cert: 'Rehab Specialist, Certified Pilates & Mobility Coach',
      image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=500&q=80'
    }
  ];

  const facilities = [
    {
      title: 'Biomechanic Strength Area',
      desc: 'Optimized machinery aligned to maintain anatomical posture and trigger pure hypertrophy safely.',
      icon: Dumbbell
    },
    {
      title: 'High-Performance Cardio Zone',
      desc: 'Top-tier treadmills, ellipticals, and air-bikes complete with heart-rate trackers and active airflow.',
      icon: Flame
    },
    {
      title: 'Posture Assessment Labs',
      desc: 'State-of-the-art camera grid analysis to identify muscular imbalances and design targeted corrections.',
      icon: Shield
    },
    {
      title: 'Functional Turf Training',
      desc: 'Sleds, kettlebells, and battle-ropes to foster explosive athletic speed, agility, and balance.',
      icon: Award
    },
    {
      title: 'Nutrition & Diet Counter',
      desc: 'Professional in-house nutritionists offering bespoke diet structures and organic supplement plans.',
      icon: Sparkles
    },
    {
      title: 'Premium Lounge & Lockers',
      desc: 'Luxurious private changing chambers, showers, secure digital lockers, and post-workout protein bar.',
      icon: Users
    }
  ];

  const testimonials = [
    {
      name: 'Karthik Gowda',
      role: 'IT Professional, Mysuru',
      quote: 'My desk job completely ruined my upper back posture. Just three months of custom alignment at The Posture Gym, and my chronic back pain is completely gone!',
      rating: 5
    },
    {
      name: 'Nisha Hegde',
      role: 'Athlete',
      quote: 'The coaching staff here is incredibly detailed. They do not just count repetitions; they focus on biomechanics, skeletal tracking, and optimal joint alignment. Outstanding environment.',
      rating: 5
    },
    {
      name: 'Aditya Swamy',
      role: 'Local Business Owner',
      quote: 'Hands down the most luxurious and cleanest gym in Mysuru. The Black, White, and Gold aesthetics are extremely inspiring. Every workout feels premium and professional.',
      rating: 5
    }
  ];

  return (
    <div id="public-root" className="min-h-screen bg-[#0a0a0a] text-gray-100 font-sans selection:bg-amber-500 selection:text-black frosted-bg">
      {/* HEADER NAVBAR */}
      <header id="nav-header" className="sticky top-0 z-50 bg-black/40 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded bg-gradient-to-br from-amber-400 via-yellow-500 to-amber-600 flex items-center justify-center text-black font-extrabold text-xl shadow-lg">
              P
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-white uppercase block leading-none">THE POSTURE</span>
              <span className="text-[10px] text-amber-500 tracking-widest font-semibold uppercase leading-none">G Y M</span>
            </div>
          </div>

          <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-gray-300">
            <a href="#about" className="hover:text-amber-500 transition-colors">About</a>
            <a href="#facilities" className="hover:text-amber-500 transition-colors">Facilities</a>
            <a href="#membership" className="hover:text-amber-500 transition-colors">Membership</a>
            <a href="#trainers" className="hover:text-amber-500 transition-colors">Trainers</a>
            <a href="#bmi" className="hover:text-amber-500 transition-colors">BMI Calculator</a>
            <a href="#contact" className="hover:text-amber-500 transition-colors">Contact</a>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              onClick={onAdminLoginClick} 
              className="text-xs text-white/75 hover:text-white transition-colors border border-white/10 px-4 h-9 rounded-md hover:bg-white/5 backdrop-blur-md"
            >
              Portal Login
            </button>
            <a 
              href="#membership" 
              className="bg-gradient-to-r from-amber-500 to-amber-600 text-black font-semibold text-xs px-4 h-9 rounded-md shadow-md shadow-amber-500/20 hover:from-amber-400 hover:to-amber-500 transition-all flex items-center"
            >
              Join Club
            </a>
          </div>
        </div>
      </header>

      {/* HERO BANNER SECTION */}
      <section id="hero-section" className="relative pt-24 pb-32 overflow-hidden flex items-center justify-center bg-[radial-gradient(ellipse_at_top,_rgba(212,175,55,0.08),_transparent_50%)] border-b border-white/5">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1920&q=80')] opacity-15 bg-cover bg-center mix-blend-luminosity"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
        
        <div className="relative max-w-5xl mx-auto px-4 text-center z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-flex items-center space-x-2 bg-zinc-900 border border-zinc-800 rounded-full px-4 py-1.5 text-xs font-semibold text-amber-500 mb-6 uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>NOW LIVE IN MYSURU, KARNATAKA</span>
            </span>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white mb-6 uppercase">
              REDEFINE YOUR <span className="bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-600 bg-clip-text text-transparent">POSTURE</span><br />
              ELEVATE YOUR <span className="text-white border-b-4 border-amber-500">STRENGTH</span>
            </h1>

            <p className="text-zinc-400 text-lg sm:text-xl max-w-3xl mx-auto mb-10 leading-relaxed">
              Experience the pinnacle of posture-centric strength and athletic conditioning. Featuring premium biomechanics, luxury changing suites, and personalized coaching to restore anatomical balance.
            </p>

            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <a 
                href="#membership" 
                className="w-full sm:w-auto bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold px-8 py-4 rounded-md flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/20 hover:scale-105 transition-all uppercase text-sm"
              >
                <span>Select Membership</span>
                <ArrowRight className="w-4 h-4" />
              </a>
              <a 
                href="#contact" 
                className="w-full sm:w-auto bg-zinc-900 hover:bg-zinc-800 text-white font-semibold px-8 py-4 rounded-md border border-zinc-800 hover:border-zinc-700 transition-all uppercase text-sm text-center"
              >
                Schedule Free Assessment
              </a>
            </div>
          </motion.div>
        </div>

        {/* Dynamic highlights */}
        <div className="absolute bottom-4 left-0 right-0 max-w-7xl mx-auto px-4 hidden lg:grid grid-cols-4 gap-6 text-center border-t border-white/10 pt-8 mt-12">
          <div>
            <span className="block text-3xl font-extrabold text-amber-500">4,500+ SqFt</span>
            <span className="text-xs text-zinc-500 uppercase tracking-widest">Premium Facility</span>
          </div>
          <div>
            <span className="block text-3xl font-extrabold text-white">Posture Lab</span>
            <span className="text-xs text-zinc-500 uppercase tracking-widest">Digital Assessment</span>
          </div>
          <div>
            <span className="block text-3xl font-extrabold text-amber-500">Elite</span>
            <span className="text-xs text-zinc-500 uppercase tracking-widest">Certified Coaches</span>
          </div>
          <div>
            <span className="block text-3xl font-extrabold text-white">24/7 Access</span>
            <span className="text-xs text-zinc-500 uppercase tracking-widest">To Premium Members</span>
          </div>
        </div>
      </section>

      {/* ABOUT THE POSTURE GYM */}
      <section id="about" className="py-24 bg-[#0a0a0a] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-amber-500"></div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 border-b-2 border-r-2 border-amber-500"></div>
              <img 
                src="https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80" 
                alt="Gym Interior" 
                className="rounded-2xl shadow-2xl object-cover w-full h-[500px] border border-white/10 grayscale hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/60 backdrop-blur-md border border-amber-500/30 p-6 rounded-2xl text-center w-64">
                <span className="text-3xl font-black text-amber-500 block">ESTD. 2024</span>
                <span className="text-xs text-zinc-400 uppercase tracking-widest">Redefining Mysuru's Health</span>
              </div>
            </div>

            <div>
              <span className="text-xs text-amber-500 uppercase tracking-widest font-bold block mb-2">OUR PHILOSOPHY</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mb-6">
                Not Just a Gym.<br />A posture Revolution.
              </h2>
              <p className="text-zinc-400 leading-relaxed mb-6">
                Most modern gym environments focus heavily on moving heavy objects without analyzing skeletal alignment. At <strong>The Posture Gym</strong>, we understand that structural integrity precedes muscular volume.
              </p>
              <p className="text-zinc-400 leading-relaxed mb-8">
                Located in the heart of Saraswathipuram, Mysuru, we are equipped with premium custom-angled strength machinery that targets kinetic chains accurately while preserving joint angles. Every membership includes automated physical assessments to eliminate desk-job syndrome, forward-neck lean, and muscular asymmetry.
              </p>

              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded bg-zinc-900 border border-zinc-800 text-amber-500">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-semibold text-white block">Postural Correctives</span>
                    <span className="text-xs text-zinc-500">Structured spinal support</span>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded bg-zinc-900 border border-zinc-800 text-amber-500">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-semibold text-white block">Biomechanics First</span>
                    <span className="text-xs text-zinc-500">Safe joint kinematics</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FACILITIES / SERVICES */}
      <section id="facilities" className="py-24 bg-black/40 backdrop-blur-xl border-y border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">STATE OF THE ART</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2">OUR LUXURY AMENITIES</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto mt-4 text-sm">
            Our facilities are regularly sanitized, perfectly temperature-controlled, and curated to provide an elite atmosphere of quiet dedication.
          </p>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {facilities.map((fac, i) => (
            <div 
              key={i} 
              className="p-8 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-500/40 backdrop-blur-md transition-all duration-300 hover:translate-y-[-4px] flex flex-col justify-between group"
            >
              <div>
                <div className="p-3 w-12 h-12 rounded-xl bg-white/5 border border-white/10 text-amber-500 mb-6 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-black transition-all">
                  <fac.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold uppercase text-white mb-3">{fac.title}</h3>
                <p className="text-zinc-400 text-sm leading-relaxed mb-6">{fac.desc}</p>
              </div>
              <span className="text-xs text-amber-500 font-semibold tracking-wider uppercase flex items-center group-hover:translate-x-2 transition-transform cursor-pointer">
                Learn Details <ChevronRight className="w-3.5 h-3.5 ml-1" />
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* MEMBERSHIP PLANS */}
      <section id="membership" className="py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">PRICING PLANS</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2">MEMBERSHIP SELECTIONS</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto mt-4 text-sm">
            Invest in your structural wellness. Transparent billing, no hidden signup dues, with flexible payment options available.
          </p>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((plan, idx) => (
            <div 
              key={idx} 
              className={`p-8 rounded-2xl flex flex-col justify-between relative border transition-all duration-300 ${
                plan.popular 
                  ? 'bg-amber-500/10 border-amber-500/50 shadow-2xl shadow-amber-500/5 backdrop-blur-lg' 
                  : 'bg-white/5 border-white/10 hover:border-white/20 backdrop-blur-md'
              }`}
            >
              {plan.popular && (
                <span className="absolute top-4 right-4 bg-amber-500 text-black text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Most Popular
                </span>
              )}
              
              <div>
                <span className="text-zinc-400 text-sm uppercase tracking-widest font-semibold block mb-2">{plan.name}</span>
                <div className="flex items-baseline mb-6">
                  <span className="text-4xl font-black text-white">{plan.price}</span>
                  <span className="text-zinc-500 text-xs ml-2">/ {plan.period}</span>
                </div>
                
                <hr className="border-white/10 mb-6" />
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start text-xs text-zinc-300">
                      <Check className="w-3.5 h-3.5 text-amber-500 mr-2 mt-0.5 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button 
                onClick={() => onJoinNow(plan.name)}
                className={`w-full py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${
                  plan.popular 
                    ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-md shadow-amber-500/20' 
                    : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                }`}
              >
                Join Now
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* INTERACTIVE BMI CALCULATOR */}
      <section id="bmi" className="py-24 bg-black/40 backdrop-blur-xl border-t border-white/10 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">KNOW YOUR METRICS</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2 mb-6">POSTURAL BMI ANALYSIS</h2>
              <p className="text-zinc-400 leading-relaxed mb-6 text-sm">
                The Body Mass Index (BMI) is a valuable general metric to determine skeletal load levels. High physical mass impacts spine compression and knee joints differently depending on structural muscle balance.
              </p>
              <p className="text-zinc-400 leading-relaxed text-sm mb-8">
                Enter your dimensions on the right. Our posture algorithm will calculate your bracket and provide targeted posture guidance that you can review during your first session at the club.
              </p>

              <div className="grid grid-cols-3 gap-4 text-center border-t border-white/10 pt-8">
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md">
                  <span className="block text-zinc-500 text-[10px] uppercase tracking-wider">Underweight</span>
                  <span className="text-sm font-semibold text-white">&lt; 18.5</span>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md">
                  <span className="block text-zinc-500 text-[10px] uppercase tracking-wider">Normal</span>
                  <span className="text-sm font-semibold text-amber-500">18.5 - 24.9</span>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-md">
                  <span className="block text-zinc-500 text-[10px] uppercase tracking-wider">Overweight</span>
                  <span className="text-sm font-semibold text-white">25 - 29.9</span>
                </div>
              </div>
            </div>

            <div className="p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
              <h3 className="text-xl font-bold uppercase text-white mb-6 flex items-center">
                <Calculator className="w-5 h-5 text-amber-500 mr-2" />
                Metric Calculator
              </h3>
              
              <form onSubmit={handleCalculateBMI} className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Weight (kg)</label>
                    <input 
                      type="number" 
                      required
                      placeholder="e.g. 72"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-amber-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-amber-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Height (cm)</label>
                    <input 
                      type="number" 
                      required
                      placeholder="e.g. 175"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 focus:border-amber-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:ring-1 focus:ring-amber-500 transition-colors"
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-bold text-xs uppercase tracking-widest rounded transition-all shadow-md shadow-amber-500/10"
                >
                  Calculate Now
                </button>
              </form>

              {bmiResult !== null && (
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-8 p-6 rounded-2xl bg-white/5 border border-amber-500/30 backdrop-blur-md"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-zinc-500 text-[10px] uppercase tracking-wider block">Your BMI Score</span>
                      <span className="text-3xl font-black text-amber-500">{bmiResult}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-zinc-500 text-[10px] uppercase tracking-wider block">Category</span>
                      <span className="text-sm font-bold text-white uppercase tracking-wider">{bmiCategory}</span>
                    </div>
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed border-t border-white/10 pt-4">
                    <strong>Posture Advice:</strong> {bmiAdvice}
                  </p>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ELITE TRAINERS */}
      <section id="trainers" className="py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">THE COACHING TEAM</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2">ELITE SKELETAL COACHES</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto mt-4 text-sm">
            Our certified specialists focus on deep kinematics, movement mechanics, and custom spinal loading alignment.
          </p>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          {trainers.map((train, i) => (
            <div key={i} className="rounded-2xl bg-white/5 border border-white/10 overflow-hidden hover:border-amber-500/40 backdrop-blur-md transition-all duration-300 group">
              <div className="h-80 relative overflow-hidden">
                <img 
                  src={train.image} 
                  alt={train.name} 
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-750"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-4">
                  <span className="bg-amber-500 text-black text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                    {train.exp}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold uppercase text-white mb-1">{train.name}</h3>
                <span className="text-xs text-amber-500 font-medium tracking-wide block mb-3 uppercase">{train.role}</span>
                <p className="text-zinc-500 text-xs leading-relaxed italic">{train.cert}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* REVIEWS & INSTAGRAM GALLERY */}
      <section id="testimonials" className="py-24 bg-black/40 backdrop-blur-xl border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">MEMBER VOICES</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2">GOOGLE REVIEWS & FEEDBACK</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((test, i) => (
              <div key={i} className="p-8 rounded-2xl bg-white/5 border border-white/10 flex flex-col justify-between backdrop-blur-md">
                <div>
                  <div className="flex items-center space-x-1 text-amber-500 mb-6">
                    {[...Array(test.rating)].map((_, r) => (
                      <Star key={r} className="w-4 h-4 fill-amber-500" />
                    ))}
                  </div>
                  <p className="text-zinc-300 text-sm italic leading-relaxed mb-6">
                    "{test.quote}"
                  </p>
                </div>
                <div className="border-t border-white/10 pt-4">
                  <span className="font-bold text-white block text-sm">{test.name}</span>
                  <span className="text-xs text-zinc-500">{test.role}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Social Showcase banner */}
          <div className="mt-16 p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-col lg:flex-row justify-between items-center space-y-6 lg:space-y-0">
            <div className="flex items-center space-x-4">
              <Instagram className="w-10 h-10 text-amber-500" />
              <div>
                <h4 className="text-lg font-bold uppercase text-white">Join our Instagram Tribe</h4>
                <p className="text-xs text-zinc-500">Track real member alignment journeys, quick posture tips, and facility updates.</p>
              </div>
            </div>
            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noreferrer"
              className="px-6 py-3 bg-white/5 border border-white/10 hover:border-amber-500/50 hover:bg-white/10 rounded-xl text-xs font-bold uppercase tracking-wider text-white transition-all backdrop-blur-md"
            >
              @ThePostureGymMysuru
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT & DETAILED MAP */}
      <section id="contact" className="py-24 bg-black/40 backdrop-blur-xl border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            
            {/* Left form & details */}
            <div>
              <span className="text-xs text-amber-500 uppercase tracking-widest font-bold">FIND THE CLUB</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold uppercase text-white mt-2 mb-6">GET IN TOUCH</h2>
              
              <div className="space-y-8 mb-12">
                <div className="flex items-start space-x-4">
                  <MapPin className="w-6 h-6 text-amber-500 shrink-0 mt-1" />
                  <div>
                    <h5 className="font-bold uppercase text-white text-sm">CLUB ADDRESS</h5>
                    <p className="text-zinc-400 text-xs leading-relaxed mt-1">
                      303, 7th Main, 3rd Cross Road, Near Mysore Donne Biryani, Saraswathipuram, Mysuru, Karnataka 570009
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="w-6 h-6 text-amber-500 shrink-0 mt-1" />
                  <div>
                    <h5 className="font-bold uppercase text-white text-sm">PHONE NUMBER</h5>
                    <p className="text-zinc-400 text-xs mt-1">
                      <a href="tel:+919731677316" className="hover:text-white transition-colors">+91 97316 77316</a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Mail className="w-6 h-6 text-amber-500 shrink-0 mt-1" />
                  <div>
                    <h5 className="font-bold uppercase text-white text-sm">EMAIL CORRESPONDENCE</h5>
                    <p className="text-zinc-400 text-xs mt-1">
                      <a href="mailto:info@theposturegym.in" className="hover:text-white transition-colors">info@theposturegym.in</a>
                    </p>
                  </div>
                </div>
              </div>

              {/* Form panel */}
              <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <h4 className="font-bold text-white uppercase text-sm mb-4">Request a Call Back</h4>
                {contactSuccess ? (
                  <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-500 text-xs">
                    Thank you! Our posture coach will call you back within 2 hours.
                  </div>
                ) : (
                  <form onSubmit={handleContactSubmit} className="space-y-4">
                    <div>
                      <input 
                        type="text" 
                        required
                        placeholder="Your Name" 
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <input 
                        type="tel" 
                        required
                        placeholder="Your Phone Number" 
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-colors"
                      />
                    </div>
                    <div>
                      <textarea 
                        placeholder="Message (Optional, e.g., desk job posture pain)" 
                        rows={3}
                        value={contactMessage}
                        onChange={(e) => setContactMessage(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-colors"
                      ></textarea>
                    </div>
                    <button 
                      type="submit"
                      className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-bold uppercase text-[10px] tracking-widest rounded-xl transition-all shadow-md shadow-amber-500/10"
                    >
                      Submit Details
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Right Map view */}
            <div className="h-[550px] relative rounded-2xl overflow-hidden border border-white/10">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3898.1568285579997!2d76.62688867597148!3d12.305105229342416!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3baf707be9e5e6e1%3A0xe5fa6b783cb0f90!2sMysore%20Donne%20Biryani!5e0!3m2!1sen!2sin!4v1716301323321!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0, filter: 'grayscale(1) invert(1) contrast(1.2)' }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
              <div className="absolute bottom-4 left-4 right-4 bg-black/80 backdrop-blur-md border border-white/10 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-amber-500 font-bold uppercase tracking-widest block">Immediate Connect</span>
                  <span className="text-xs text-white font-semibold">Start Chatting on WhatsApp</span>
                </div>
                <a 
                  href="https://wa.me/919731677316" 
                  target="_blank" 
                  rel="noreferrer"
                  className="bg-[#25D366] hover:bg-[#20ba5a] text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center transition-colors"
                >
                  Chat Now
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* FOOTER BAR */}
      <footer className="bg-[#0a0a0a] border-t border-white/10 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-3 mb-6 md:mb-0">
            <div className="w-8 h-8 rounded bg-amber-500 flex items-center justify-center text-black font-black text-sm">
              P
            </div>
            <div>
              <span className="font-extrabold text-sm text-white uppercase block leading-none">THE POSTURE</span>
              <span className="text-[8px] text-amber-500 tracking-widest font-semibold uppercase leading-none">G Y M</span>
            </div>
          </div>

          <p className="text-zinc-600 text-xs text-center md:text-left mb-6 md:mb-0">
            &copy; {new Date().getFullYear()} The Posture Gym Mysuru. All Rights Reserved. Biomechanical Excellence.
          </p>

          <div className="flex space-x-6 text-zinc-500 text-xs">
            <a href="#about" className="hover:text-white transition-colors">Safety</a>
            <a href="#membership" className="hover:text-white transition-colors">Membership Guidelines</a>
            <a href="#contact" className="hover:text-white transition-colors">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
