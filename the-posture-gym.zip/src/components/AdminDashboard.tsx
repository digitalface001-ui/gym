import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, DollarSign, Calendar, Clock, AlertTriangle, Search, 
  Plus, Edit2, Trash2, Download, Printer, RefreshCw, Send, 
  Settings, BarChart2, Bell, Shield, Phone, Mail, FileText, 
  CreditCard, CheckCircle, XCircle, LogOut, ChevronDown, Check,
  SlidersHorizontal, ShieldAlert, Award, ArrowUpRight
} from 'lucide-react';
import { Member, Payment, ReminderLog, AdminNotification, GymSettings, DashboardStats } from '../types';

interface AdminDashboardProps {
  token: string;
  onLogout: () => void;
}

export default function AdminDashboard({ token, onLogout }: AdminDashboardProps) {
  // Navigation
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'payments' | 'reminders' | 'reports' | 'settings'>('overview');

  // Core Data State
  const [stats, setStats] = useState<any>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [reminders, setReminders] = useState<ReminderLog[]>([]);
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [settings, setSettings] = useState<GymSettings | null>(null);
  const [loading, setLoading] = useState(true);

  // Filter/Search States for Member CRM
  const [memberSearch, setMemberSearch] = useState('');
  const [planFilter, setPlanFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'name' | 'expiry' | 'joining'>('expiry');

  // Modals
  const [showMemberModal, setShowMemberModal] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedMemberForPayment, setSelectedMemberForPayment] = useState<Member | null>(null);
  const [showRenewModal, setShowRenewModal] = useState(false);
  const [selectedMemberForRenewal, setSelectedMemberForRenewal] = useState<Member | null>(null);
  const [showReceipt, setShowReceipt] = useState<Payment | null>(null);

  // Notification states
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Form states - Member
  const [memberForm, setMemberForm] = useState({
    fullName: '', phone: '', email: '', gender: 'Male', dob: '',
    address: '', emergencyContact: '', membershipPlan: '',
    joiningDate: '', membershipExpiryDate: '', paymentStatus: 'Paid',
    amountPaid: 0, remainingBalance: 0, notes: '', photoUrl: ''
  });

  // Form states - Payment
  const [paymentForm, setPaymentForm] = useState({
    amount: '', status: 'Paid', notes: '', planName: ''
  });

  // Form states - Renewal
  const [renewalForm, setRenewalForm] = useState({
    planId: '', amountPaid: '', joiningDate: '', notes: ''
  });

  // Form states - Settings
  const [settingsForm, setSettingsForm] = useState<GymSettings | null>(null);

  // Trigger automation loading feedback
  const [triggeringAutomation, setTriggeringAutomation] = useState(false);

  // Fetch all dashboard data
  const fetchData = async () => {
    setLoading(true);
    try {
      const headers = { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };
      
      const [resStats, resMembers, resPayments, resReminders, resSettings] = await Promise.all([
        fetch('/api/reports/dashboard', { headers }),
        fetch('/api/members', { headers }),
        fetch('/api/payments', { headers }),
        fetch('/api/reminders', { headers }),
        fetch('/api/settings', { headers })
      ]);

      const dataStats = await resStats.json();
      const dataMembers = await resMembers.json();
      const dataPayments = await resPayments.json();
      const dataReminders = await resReminders.json();
      const dataSettings = await resSettings.json();

      setStats(dataStats);
      setMembers(dataMembers);
      setPayments(dataPayments);
      setReminders(dataReminders);
      setSettings(dataSettings);
      setSettingsForm(dataSettings);
      
      if (dataStats.notifications) {
        setNotifications(dataStats.notifications);
        setUnreadCount(dataStats.notifications.filter((n: any) => !n.read).length);
      }
    } catch (e) {
      console.error("Error loading dashboard metrics:", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [token, activeTab]);

  // Handle Mark All Notifications Read
  const handleMarkNotifRead = async () => {
    try {
      await fetch('/api/notifications/mark-read', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (e) {
      console.error(e);
    }
  };

  // Trigger Automated check now
  const handleTriggerAutomation = async () => {
    setTriggeringAutomation(true);
    try {
      const res = await fetch('/api/reminders/trigger-check', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const result = await res.json();
      alert(`Automation Complete!\n\nChecked: ${result.totalChecked} members.\nSuccessfully sent reminders: ${result.successfulReminders}.\nFailed attempts: ${result.failedReminders}.`);
      fetchData();
    } catch (e) {
      alert("Failed to run reminder engine");
    } finally {
      setTriggeringAutomation(false);
    }
  };

  // Individual Manual reminder send
  const handleSendManualReminder = async (memberId: string) => {
    try {
      const res = await fetch('/api/reminders/send-manual', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ memberId })
      });
      const data = await res.json();
      if (data.success) {
        alert("WhatsApp reminder dispatched successfully!");
      } else {
        alert(`Failed: ${data.error || "Unknown error"}`);
      }
      fetchData();
    } catch (e) {
      alert("Error sending reminder");
    }
  };

  // Submit Member Form (Create / Update)
  const handleMemberSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const headers = { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };

      if (editingMember) {
        // Edit Member
        await fetch(`/api/members/${editingMember.id}`, {
          method: 'PUT',
          headers,
          body: JSON.stringify(memberForm)
        });
      } else {
        // Create Member
        await fetch('/api/members', {
          method: 'POST',
          headers,
          body: JSON.stringify(memberForm)
        });
      }
      setShowMemberModal(false);
      setEditingMember(null);
      fetchData();
    } catch (err) {
      alert("Error saving member");
    }
  };

  // Delete Member
  const handleDeleteMember = async (id: string) => {
    if (!confirm("Are you absolutely sure you want to remove this member? This will clear their record.")) return;
    try {
      await fetch(`/api/members/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchData();
    } catch (e) {
      alert("Error removing member");
    }
  };

  // Record custom payment
  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMemberForPayment) return;
    try {
      const res = await fetch('/api/payments/record', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          memberId: selectedMemberForPayment.id,
          amount: parseFloat(paymentForm.amount),
          status: paymentForm.status,
          notes: paymentForm.notes,
          planName: paymentForm.planName
        })
      });
      if (res.ok) {
        setShowPaymentModal(false);
        setSelectedMemberForPayment(null);
        fetchData();
      }
    } catch (e) {
      alert("Error recording payment");
    }
  };

  // Process Renewal
  const handleRenewalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMemberForRenewal) return;
    try {
      const res = await fetch('/api/payments/renew', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          memberId: selectedMemberForRenewal.id,
          planId: renewalForm.planId,
          amountPaid: parseFloat(renewalForm.amountPaid),
          joiningDate: renewalForm.joiningDate,
          notes: renewalForm.notes
        })
      });
      if (res.ok) {
        setShowRenewModal(false);
        setSelectedMemberForRenewal(null);
        fetchData();
      }
    } catch (e) {
      alert("Error processing renewal");
    }
  };

  // Save Settings
  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settingsForm) return;
    try {
      await fetch('/api/settings/save', {
        method: 'POST',
        headers: { 
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settingsForm)
      });
      alert("Settings saved successfully!");
      fetchData();
    } catch (e) {
      alert("Error saving settings");
    }
  };

  // Trigger edit modal
  const openEditModal = (member: Member) => {
    setEditingMember(member);
    setMemberForm({
      fullName: member.fullName,
      phone: member.phone,
      email: member.email,
      gender: member.gender,
      dob: member.dob,
      address: member.address,
      emergencyContact: member.emergencyContact,
      membershipPlan: member.membershipPlan,
      joiningDate: member.joiningDate,
      membershipExpiryDate: member.membershipExpiryDate,
      paymentStatus: member.paymentStatus,
      amountPaid: member.amountPaid,
      remainingBalance: member.remainingBalance,
      notes: member.notes,
      photoUrl: member.photoUrl || ''
    });
    setShowMemberModal(true);
  };

  // Trigger add modal
  const openAddModal = () => {
    setEditingMember(null);
    setMemberForm({
      fullName: '', phone: '', email: '', gender: 'Male', dob: '',
      address: '', emergencyContact: '', membershipPlan: settings?.plans[0]?.name || 'Monthly Elite',
      joiningDate: new Date().toISOString().split('T')[0],
      membershipExpiryDate: (() => {
        const d = new Date();
        d.setMonth(d.getMonth() + 1);
        return d.toISOString().split('T')[0];
      })(),
      paymentStatus: 'Paid',
      amountPaid: settings?.plans[0]?.price || 2500,
      remainingBalance: 0,
      notes: '',
      photoUrl: ''
    });
    setShowMemberModal(true);
  };

  // Export CSV
  const handleExportCSV = () => {
    const csvRows = [
      ['Member ID', 'Full Name', 'Phone', 'Email', 'Plan', 'Expiry Date', 'Payment Status', 'Balance']
    ];
    members.forEach(m => {
      csvRows.push([
        m.id, m.fullName, m.phone, m.email, m.membershipPlan, m.membershipExpiryDate, m.paymentStatus, m.remainingBalance.toString()
      ]);
    });
    const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `PostureGym_Members_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Print list
  const handlePrintMembers = () => {
    window.print();
  };

  // Filter & Sort Logic
  const filteredMembers = members.filter(m => {
    const matchesSearch = m.fullName.toLowerCase().includes(memberSearch.toLowerCase()) || 
                          m.phone.includes(memberSearch) || 
                          m.id.toLowerCase().includes(memberSearch.toLowerCase());
    
    const matchesPlan = planFilter === 'All' || m.membershipPlan === planFilter;
    
    // Status Logic
    const today = new Date().toISOString().split('T')[0];
    const isExpired = m.membershipExpiryDate < today;
    
    const d = new Date();
    d.setDate(d.getDate() + 3);
    const d3 = d.toISOString().split('T')[0];
    const isExpiringSoon = m.membershipExpiryDate >= today && m.membershipExpiryDate <= d3;

    let matchesStatus = true;
    if (statusFilter === 'Active') {
      matchesStatus = !isExpired;
    } else if (statusFilter === 'Expired') {
      matchesStatus = isExpired;
    } else if (statusFilter === 'ExpiringSoon') {
      matchesStatus = isExpiringSoon;
    }

    return matchesSearch && matchesPlan && matchesStatus;
  }).sort((a, b) => {
    if (sortBy === 'name') {
      return a.fullName.localeCompare(b.fullName);
    } else if (sortBy === 'joining') {
      return b.joiningDate.localeCompare(a.joiningDate);
    } else {
      return a.membershipExpiryDate.localeCompare(b.membershipExpiryDate);
    }
  });

  return (
    <div id="admin-root" className="min-h-screen bg-[#0a0a0a] text-gray-100 font-sans selection:bg-amber-500 selection:text-black flex flex-col">
      {/* TOP HEADER */}
      <header className="h-16 border-b border-white/10 bg-black/40 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded bg-gradient-to-r from-amber-500 to-amber-600 flex items-center justify-center text-black font-extrabold text-sm shadow-md">
            P
          </div>
          <div>
            <span className="font-extrabold text-sm tracking-tight text-white uppercase block leading-none">THE POSTURE</span>
            <span className="text-[8px] text-amber-500 tracking-widest font-bold uppercase leading-none">M A N A G E R</span>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          {/* Notifications bell */}
          <div className="relative">
            <button 
              onClick={() => {
                setShowNotifDropdown(!showNotifDropdown);
                if (!showNotifDropdown) handleMarkNotifRead();
              }}
              className="p-2 text-zinc-400 hover:text-white rounded hover:bg-zinc-900 relative transition-all"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-amber-500 text-black text-[9px] font-black rounded-full flex items-center justify-center animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Notif Dropdown */}
            {showNotifDropdown && (
              <div className="absolute right-0 mt-2 w-80 rounded bg-zinc-900 border border-zinc-800 shadow-xl py-2 z-50 text-xs">
                <div className="px-4 py-2 border-b border-zinc-800 flex justify-between items-center">
                  <span className="font-bold text-white uppercase">RENEWAL REMINDERS</span>
                  <button onClick={() => setShowNotifDropdown(false)} className="text-[10px] text-zinc-500 hover:text-white">Close</button>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-6 text-center text-zinc-500">No alerts logged today.</div>
                  ) : (
                    notifications.map((notif) => (
                      <div key={notif.id} className="p-3 border-b border-zinc-800/50 hover:bg-zinc-800/30">
                        <div className="flex justify-between items-start">
                          <span className={`px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase ${
                            notif.type === 'success' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
                          }`}>
                            {notif.type}
                          </span>
                          <span className="text-[9px] text-zinc-600">
                            {new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-zinc-300 mt-1">{notif.message}</p>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="h-8 w-px bg-zinc-800"></div>

          <button 
            onClick={onLogout} 
            className="flex items-center space-x-2 text-xs text-zinc-400 hover:text-rose-400 transition-colors bg-zinc-900/50 border border-zinc-800 px-3 py-1.5 rounded"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Portal Logout</span>
          </button>
        </div>
      </header>

      {/* CORE SPLIT SCREEN */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* SIDE BAR RAIL */}
        <aside className="w-64 border-r border-white/10 bg-black/40 backdrop-blur-xl p-4 flex flex-col justify-between hidden md:flex">
          <div className="space-y-2">
            <button 
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all border-l-2 ${
                activeTab === 'overview' 
                  ? 'bg-gradient-to-r from-amber-500/25 to-transparent border-amber-500 text-white font-semibold' 
                  : 'text-white/50 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <BarChart2 className="w-4 h-4 shrink-0" />
              <span>Overview</span>
            </button>

            <button 
              onClick={() => setActiveTab('members')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all border-l-2 ${
                activeTab === 'members' 
                  ? 'bg-gradient-to-r from-amber-500/25 to-transparent border-amber-500 text-white font-semibold' 
                  : 'text-white/50 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <Users className="w-4 h-4 shrink-0" />
              <span>Members CRM</span>
            </button>

            <button 
              onClick={() => setActiveTab('payments')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all border-l-2 ${
                activeTab === 'payments' 
                  ? 'bg-gradient-to-r from-amber-500/25 to-transparent border-amber-500 text-white font-semibold' 
                  : 'text-white/50 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <CreditCard className="w-4 h-4 shrink-0" />
              <span>Payments Ledger</span>
            </button>

            <button 
              onClick={() => setActiveTab('reminders')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all border-l-2 ${
                activeTab === 'reminders' 
                  ? 'bg-gradient-to-r from-amber-500/25 to-transparent border-amber-500 text-white font-semibold' 
                  : 'text-white/50 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <Phone className="w-4 h-4 shrink-0" />
              <span>WhatsApp Alerts</span>
            </button>

            <button 
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-sm font-medium transition-all border-l-2 ${
                activeTab === 'settings' 
                  ? 'bg-gradient-to-r from-amber-500/25 to-transparent border-amber-500 text-white font-semibold' 
                  : 'text-white/50 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <Settings className="w-4 h-4 shrink-0" />
              <span>Club Settings</span>
            </button>
          </div>

          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 text-center backdrop-blur-md">
            <span className="text-[10px] text-amber-500 block font-bold tracking-widest uppercase">SYSTEM DATE</span>
            <span className="text-xs font-mono text-white/75 mt-1 block">2026-07-21 (Mysuru)</span>
          </div>
        </aside>

        {/* MAIN BODY AREA */}
        <main className="flex-1 overflow-y-auto p-8 bg-[radial-gradient(circle_at_top_right,_rgba(212,175,55,0.08),_transparent_50%)] bg-[#0a0a0a]">
          
          {loading ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <RefreshCw className="w-8 h-8 text-amber-500 animate-spin mx-auto mb-4" />
                <span className="text-zinc-500 text-sm">Synchronizing ledger systems...</span>
              </div>
            </div>
          ) : (
            <div>
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && stats && (
                <div className="space-y-8">
                  {/* Dashboard header */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div>
                      <h2 className="text-2xl font-black uppercase text-white tracking-tight">OPERATIONAL OVERVIEW</h2>
                      <p className="text-xs text-zinc-500 mt-1">Real-time indicators for membership cycles and billing pipelines.</p>
                    </div>
                    <button 
                      onClick={handleTriggerAutomation}
                      disabled={triggeringAutomation}
                      className="mt-4 md:mt-0 flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black px-4 py-2.5 rounded font-bold text-xs uppercase shadow-md shadow-amber-500/10"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${triggeringAutomation ? 'animate-spin' : ''}`} />
                      <span>Run Automation Check</span>
                    </button>
                  </div>

                  {/* Kpis Grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-lg">
                      <div className="flex justify-between items-start text-white/40">
                        <span className="text-xs font-semibold uppercase tracking-widest">Total Members</span>
                        <Users className="w-4 h-4 text-white/50" />
                      </div>
                      <span className="block text-3xl font-light italic text-white mt-4">{stats.totalMembers}</span>
                      <span className="text-[10px] text-white/30 uppercase tracking-widest mt-2 block">All registered database entries</span>
                    </div>

                    <div className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-lg relative overflow-hidden group">
                      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-emerald-500/5 to-transparent rounded-bl-full"></div>
                      <div className="flex justify-between items-start text-white/40">
                        <span className="text-xs font-semibold uppercase tracking-widest">Active Members</span>
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                      </div>
                      <span className="block text-3xl font-light italic text-white mt-4">{stats.activeMembers}</span>
                      <span className="text-[10px] text-emerald-400/80 font-semibold uppercase mt-2 block">Expiry &gt;= Today</span>
                    </div>

                    <div className="bg-amber-500/10 border border-amber-500/30 p-6 rounded-2xl backdrop-blur-lg relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-amber-500/5 to-transparent rounded-bl-full"></div>
                      <div className="flex justify-between items-start text-amber-500/60">
                        <span className="text-xs font-semibold uppercase tracking-widest">Expiring (3 Days)</span>
                        <Clock className="w-4 h-4 text-amber-500 animate-pulse" />
                      </div>
                      <span className="block text-3xl font-light italic text-amber-500 mt-4">{stats.expiringIn3Days}</span>
                      <span className="text-[10px] text-amber-500 font-bold uppercase mt-2 block">WhatsApp Target Reminders</span>
                    </div>

                    <div className="bg-white/5 border border-white/10 p-6 rounded-2xl backdrop-blur-lg">
                      <div className="flex justify-between items-start text-white/40">
                        <span className="text-xs font-semibold uppercase tracking-widest">Expired Members</span>
                        <AlertTriangle className="w-4 h-4 text-white/30" />
                      </div>
                      <span className="block text-3xl font-light italic text-white/60 mt-4">{stats.expiredMembers}</span>
                      <span className="text-[10px] text-white/30 uppercase mt-2 block">Dormant - Awaiting Renewals</span>
                    </div>
                  </div>

                  {/* Financial KPI stats */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-lg">
                    <div>
                      <span className="text-white/40 text-xs font-semibold uppercase tracking-widest">Today's Collections</span>
                      <span className="block text-2xl font-light italic text-white mt-1">₹{stats.todayRevenue.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-amber-500/60 text-xs font-semibold uppercase tracking-widest">Monthly Collections</span>
                      <span className="block text-2xl font-light italic text-amber-500 mt-1">₹{stats.monthlyRevenue.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-white/40 text-xs font-semibold uppercase tracking-widest">Annual Collections</span>
                      <span className="block text-2xl font-light italic text-white mt-1">₹{stats.annualRevenue.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Bottom Half Grid: Graphs & Activity Log */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    
                    {/* Visual Charts simulation */}
                    <div className="lg:col-span-2 bg-black p-6 rounded border border-zinc-900 space-y-6">
                      <span className="text-xs font-bold uppercase text-white tracking-wider block border-b border-zinc-900 pb-4">Membership Distributions</span>
                      <div className="grid grid-cols-4 gap-4 h-48 items-end pt-4">
                        {stats.planDistribution.map((plan: any, i: number) => {
                          const maxVal = Math.max(...stats.planDistribution.map((p: any) => p.value), 1);
                          const pct = (plan.value / maxVal) * 100;
                          return (
                            <div key={i} className="flex flex-col items-center space-y-3 h-full justify-end">
                              <span className="text-[11px] font-black text-amber-500">{plan.value}</span>
                              <div 
                                className="w-12 bg-gradient-to-t from-amber-600 via-amber-500 to-amber-400 rounded-t group relative hover:opacity-85 cursor-pointer transition-all"
                                style={{ height: `${pct * 0.7}%` }}
                              >
                                <div className="absolute top-[-24px] left-1/2 transform -translate-x-1/2 bg-zinc-900 border border-zinc-800 text-[9px] px-1 py-0.5 rounded text-white opacity-0 group-hover:opacity-100 whitespace-nowrap">
                                  {plan.name}
                                </div>
                              </div>
                              <span className="text-[9px] text-zinc-500 font-semibold tracking-wider text-center truncate w-full">{plan.name.split(' ')[0]}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Quick Notifications feed */}
                    <div className="bg-black p-6 rounded border border-zinc-900 flex flex-col justify-between">
                      <div>
                        <span className="text-xs font-bold uppercase text-white tracking-wider block border-b border-zinc-900 pb-4">Recent Alert Logs</span>
                        <div className="space-y-4 mt-4 max-h-[220px] overflow-y-auto pr-1">
                          {stats.notifications && stats.notifications.length === 0 ? (
                            <p className="text-zinc-600 text-xs italic text-center py-6">No notifications sent.</p>
                          ) : (
                            stats.notifications?.slice(0, 5).map((notif: any) => (
                              <div key={notif.id} className="text-xs border-b border-zinc-900/50 pb-3 last:border-0">
                                <div className="flex justify-between text-[10px] text-zinc-500">
                                  <span>{notif.memberName}</span>
                                  <span>{new Date(notif.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                </div>
                                <p className="text-zinc-300 mt-1">{notif.message}</p>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      <button 
                        onClick={() => setActiveTab('reminders')}
                        className="w-full mt-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded text-xs font-bold uppercase border border-zinc-800 tracking-wider"
                      >
                        View Full Logs
                      </button>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB 2: MEMBERS DIRECTORY */}
              {activeTab === 'members' && (
                <div className="space-y-6">
                  {/* Section Title & Buttons */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div>
                      <h2 className="text-2xl font-black uppercase text-white tracking-tight">MEMBERS REGISTER</h2>
                      <p className="text-xs text-zinc-500 mt-1">Manage physical records, profile details, and billing schedules.</p>
                    </div>
                    <div className="flex flex-wrap gap-3 mt-4 md:mt-0">
                      <button 
                        onClick={openAddModal}
                        className="bg-amber-500 hover:bg-amber-400 text-black px-4 py-2.5 rounded font-bold text-xs uppercase flex items-center space-x-2"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add New Member</span>
                      </button>
                      <button 
                        onClick={handleExportCSV}
                        className="bg-zinc-900 hover:bg-zinc-800 text-zinc-300 px-4 py-2.5 rounded font-bold text-xs uppercase border border-zinc-800 flex items-center space-x-2"
                      >
                        <Download className="w-4 h-4" />
                        <span>Export CSV</span>
                      </button>
                    </div>
                  </div>

                  {/* Filters bar */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-black p-4 rounded border border-zinc-900">
                    {/* Search query */}
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-zinc-500" />
                      <input 
                        type="text" 
                        placeholder="Search by name, ID, or phone..." 
                        value={memberSearch}
                        onChange={(e) => setMemberSearch(e.target.value)}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded pl-10 pr-4 py-2.5 text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                      />
                    </div>

                    {/* Filter Plan */}
                    <select 
                      value={planFilter}
                      onChange={(e) => setPlanFilter(e.target.value)}
                      className="bg-zinc-900 border border-zinc-800 rounded px-3 py-2.5 text-xs text-zinc-300 focus:outline-none"
                    >
                      <option value="All">All Plans</option>
                      {settings?.plans.map(p => (
                        <option key={p.id} value={p.name}>{p.name}</option>
                      ))}
                    </select>

                    {/* Filter Expiry */}
                    <select 
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value)}
                      className="bg-zinc-900 border border-zinc-800 rounded px-3 py-2.5 text-xs text-zinc-300 focus:outline-none"
                    >
                      <option value="All">All Statuses</option>
                      <option value="Active">Active</option>
                      <option value="Expired">Expired</option>
                      <option value="ExpiringSoon">Expiring Soon (3 Days)</option>
                    </select>

                    {/* Sorting */}
                    <select 
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value as any)}
                      className="bg-zinc-900 border border-zinc-800 rounded px-3 py-2.5 text-xs text-zinc-300 focus:outline-none"
                    >
                      <option value="expiry">Sort by Expiry Date</option>
                      <option value="name">Sort by Name</option>
                      <option value="joining">Sort by Joining Date</option>
                    </select>
                  </div>

                  {/* Members Table */}
                  <div className="bg-black rounded border border-zinc-900 overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-900 bg-zinc-900/20 text-zinc-500 text-[10px] uppercase font-bold tracking-wider">
                          <th className="p-4">Member ID</th>
                          <th className="p-4">Full Name</th>
                          <th className="p-4">Phone / Email</th>
                          <th className="p-4">Membership Plan</th>
                          <th className="p-4">Expiry Date</th>
                          <th className="p-4">Payment Status</th>
                          <th className="p-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredMembers.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-zinc-500 text-xs italic">
                              No members match your search criteria. Try modifying your filters.
                            </td>
                          </tr>
                        ) : (
                          filteredMembers.map((m) => {
                            const today = new Date().toISOString().split('T')[0];
                            const isExpired = m.membershipExpiryDate < today;
                            
                            const d = new Date();
                            d.setDate(d.getDate() + 3);
                            const d3 = d.toISOString().split('T')[0];
                            const isExpiringSoon = m.membershipExpiryDate === d3;

                            return (
                              <tr key={m.id} className="border-b border-zinc-900 hover:bg-zinc-900/10 text-xs">
                                <td className="p-4 font-mono font-bold text-amber-500">{m.id}</td>
                                <td className="p-4 font-bold text-white">{m.fullName}</td>
                                <td className="p-4 text-zinc-400">
                                  <div>{m.phone}</div>
                                  <div className="text-[10px] text-zinc-600">{m.email}</div>
                                </td>
                                <td className="p-4 text-zinc-300">{m.membershipPlan}</td>
                                <td className="p-4">
                                  <div className="flex items-center space-x-2">
                                    <span className="text-zinc-300">{m.membershipExpiryDate}</span>
                                    {isExpired ? (
                                      <span className="bg-rose-500/10 text-rose-500 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">Expired</span>
                                    ) : isExpiringSoon ? (
                                      <span className="bg-amber-500/10 text-amber-500 text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider animate-pulse">Alert</span>
                                    ) : (
                                      <span className="bg-emerald-500/10 text-emerald-500 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">Active</span>
                                    )}
                                  </div>
                                </td>
                                <td className="p-4">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    m.paymentStatus === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' :
                                    m.paymentStatus === 'Partial' ? 'bg-amber-500/10 text-amber-500' : 'bg-rose-500/10 text-rose-500'
                                  }`}>
                                    {m.paymentStatus}
                                  </span>
                                  {m.remainingBalance > 0 && (
                                    <div className="text-[9px] text-zinc-500 mt-1">Dues: ₹{m.remainingBalance}</div>
                                  )}
                                </td>
                                <td className="p-4 text-right space-x-1 whitespace-nowrap">
                                  <button 
                                    onClick={() => {
                                      setSelectedMemberForRenewal(m);
                                      const p = settings?.plans.find(x => x.name === m.membershipPlan);
                                      setRenewalForm({
                                        planId: p?.id || settings?.plans[0]?.id || '',
                                        amountPaid: (p?.price || 2500).toString(),
                                        joiningDate: new Date().toISOString().split('T')[0],
                                        notes: ''
                                      });
                                      setShowRenewModal(true);
                                    }}
                                    className="p-1.5 bg-zinc-900 hover:bg-amber-500 hover:text-black text-amber-500 rounded text-[10px] uppercase font-bold tracking-wider"
                                    title="Renew / Change Plan"
                                  >
                                    Renew
                                  </button>
                                  <button 
                                    onClick={() => {
                                      setSelectedMemberForPayment(m);
                                      setPaymentForm({
                                        amount: m.remainingBalance.toString(),
                                        status: 'Paid',
                                        notes: '',
                                        planName: m.membershipPlan
                                      });
                                      setShowPaymentModal(true);
                                    }}
                                    className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded"
                                    title="Record payment"
                                  >
                                    <DollarSign className="w-3.5 h-3.5" />
                                  </button>
                                  <button 
                                    onClick={() => openEditModal(m)}
                                    className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 rounded hover:text-white"
                                    title="Edit member record"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button 
                                    onClick={() => handleDeleteMember(m.id)}
                                    className="p-1.5 bg-zinc-900 hover:bg-rose-500/10 text-zinc-600 rounded hover:text-rose-400"
                                    title="Delete member"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                  <button 
                                    onClick={() => handleSendManualReminder(m.id)}
                                    className="p-1.5 bg-zinc-900 hover:bg-[#25D366]/10 text-zinc-500 hover:text-[#25D366] rounded"
                                    title="Disptach manual reminder"
                                  >
                                    <Send className="w-3.5 h-3.5" />
                                  </button>
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: PAYMENTS LEDGER */}
              {activeTab === 'payments' && (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div>
                      <h2 className="text-2xl font-black uppercase text-white tracking-tight">PAYMENTS LEDGER</h2>
                      <p className="text-xs text-zinc-500 mt-1">Transaction audit trails, dues mapping, and instant billing receipt generation.</p>
                    </div>
                  </div>

                  <div className="bg-black rounded border border-zinc-900 overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-900 bg-zinc-900/20 text-zinc-500 text-[10px] uppercase font-bold">
                          <th className="p-4">Receipt No</th>
                          <th className="p-4">Member ID / Name</th>
                          <th className="p-4">Amount</th>
                          <th className="p-4">Transaction Date</th>
                          <th className="p-4">Membership Plan</th>
                          <th className="p-4">Payment Type</th>
                          <th className="p-4 text-right">Invoice</th>
                        </tr>
                      </thead>
                      <tbody>
                        {payments.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-zinc-500 text-xs italic">
                              No payments recorded.
                            </td>
                          </tr>
                        ) : (
                          payments.map((p) => (
                            <tr key={p.id} className="border-b border-zinc-900 text-xs">
                              <td className="p-4 font-mono font-bold text-amber-500">{p.receiptNo}</td>
                              <td className="p-4">
                                <div className="font-bold text-white">{p.memberName}</div>
                                <div className="text-[10px] text-zinc-500">ID: {p.memberId}</div>
                              </td>
                              <td className="p-4 font-bold text-white">₹{p.amount.toLocaleString()}</td>
                              <td className="p-4 text-zinc-400">{p.date}</td>
                              <td className="p-4 text-zinc-300">{p.plan}</td>
                              <td className="p-4">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  p.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                                }`}>
                                  {p.status}
                                </span>
                              </td>
                              <td className="p-4 text-right">
                                <button 
                                  onClick={() => setShowReceipt(p)}
                                  className="p-1 px-2 border border-zinc-800 hover:border-amber-500 text-zinc-400 hover:text-white rounded text-[10px] uppercase font-bold"
                                >
                                  Invoice
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 4: WHATSAPP ALERTS */}
              {activeTab === 'reminders' && (
                <div className="space-y-6">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <div>
                      <h2 className="text-2xl font-black uppercase text-white tracking-tight">WHATSAPP REMINDERS AUTOMATION</h2>
                      <p className="text-xs text-zinc-500 mt-1">Automatic 9:00 AM dispatch trails, deliverability tracking, and retry queues.</p>
                    </div>
                  </div>

                  <div className="p-6 rounded bg-zinc-900/10 border border-zinc-900 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                    <div>
                      <h4 className="font-bold text-white uppercase text-sm">Cron Job: Daily at 9:00 AM</h4>
                      <p className="text-xs text-zinc-500 mt-1">
                        Checks the database for active memberships expiring in exactly 3 days and automatically fires templates.
                      </p>
                    </div>
                    <button 
                      onClick={handleTriggerAutomation}
                      className="px-6 py-3 bg-amber-500 text-black rounded font-black text-xs uppercase tracking-wider hover:bg-amber-400 shadow-lg shadow-amber-500/15"
                    >
                      Trigger Automated Run Now
                    </button>
                  </div>

                  <div className="bg-black rounded border border-zinc-900 overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-zinc-900 bg-zinc-900/20 text-zinc-500 text-[10px] uppercase font-bold">
                          <th className="p-4">Log ID</th>
                          <th className="p-4">Recipient</th>
                          <th className="p-4">Target Phone</th>
                          <th className="p-4">Expiry Checked</th>
                          <th className="p-4">Dispatch Timestamp</th>
                          <th className="p-4">Delivery Status</th>
                          <th className="p-4 text-right">Remarks</th>
                        </tr>
                      </thead>
                      <tbody>
                        {reminders.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-zinc-500 text-xs italic">
                              No automated reminders logged yet.
                            </td>
                          </tr>
                        ) : (
                          reminders.map((log) => (
                            <tr key={log.id} className="border-b border-zinc-900 text-xs">
                              <td className="p-4 font-mono text-zinc-500">{log.id}</td>
                              <td className="p-4 font-bold text-white">{log.memberName}</td>
                              <td className="p-4 text-zinc-400">{log.phone}</td>
                              <td className="p-4 text-zinc-300">{log.expiryDate}</td>
                              <td className="p-4 text-zinc-400">
                                {new Date(log.timestamp).toLocaleString()}
                              </td>
                              <td className="p-4">
                                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                  log.status === 'Success' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'
                                }`}>
                                  {log.status}
                                </span>
                              </td>
                              <td className="p-4 text-right text-zinc-500 text-[11px] max-w-xs truncate">
                                {log.error || "Official Cloud API Call"}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 5: CLUB SETTINGS */}
              {activeTab === 'settings' && settingsForm && (
                <div className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-black uppercase text-white tracking-tight">CLUB CONFIGURATIONS</h2>
                    <p className="text-xs text-zinc-500 mt-1">Configure physical branding details, WhatsApp template headers, and active plan matrixes.</p>
                  </div>

                  <form onSubmit={handleSettingsSubmit} className="space-y-8 max-w-4xl">
                    {/* General Gym Details */}
                    <div className="bg-black p-6 rounded border border-zinc-900 space-y-6">
                      <span className="text-xs font-bold uppercase text-amber-500 tracking-wider block border-b border-zinc-900 pb-3">1. GYM INFORMATION</span>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">Gym Name</label>
                          <input 
                            type="text" 
                            required
                            value={settingsForm.gymName}
                            onChange={(e) => setSettingsForm({ ...settingsForm, gymName: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">Contact Phone</label>
                          <input 
                            type="text" 
                            required
                            value={settingsForm.phone}
                            onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                          />
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">Physical Address</label>
                          <input 
                            type="text" 
                            required
                            value={settingsForm.address}
                            onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* WhatsApp Credentials */}
                    <div className="bg-black p-6 rounded border border-zinc-900 space-y-6">
                      <span className="text-xs font-bold uppercase text-amber-500 tracking-wider block border-b border-zinc-900 pb-3">2. META WHATSAPP BUSINESS Cloud API CREDENTIALS</span>
                      <p className="text-zinc-500 text-[11px] leading-relaxed">
                        To enable official production message delivery, supply your Facebook Developer system settings. If kept blank, the system automatically runs in <strong>Simulation Sandbox Mode</strong>.
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">Permanent Graph API System Token</label>
                          <input 
                            type="password" 
                            placeholder="EAArZCsS8Wq8wBA..."
                            value={settingsForm.whatsappToken}
                            onChange={(e) => setSettingsForm({ ...settingsForm, whatsappToken: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">WhatsApp Phone ID</label>
                          <input 
                            type="text" 
                            placeholder="e.g. 10485934584"
                            value={settingsForm.whatsappPhoneId}
                            onChange={(e) => setSettingsForm({ ...settingsForm, whatsappPhoneId: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-zinc-400 uppercase mb-2">WhatsApp Template Name (Approved)</label>
                          <input 
                            type="text" 
                            value={settingsForm.whatsappTemplateName}
                            onChange={(e) => setSettingsForm({ ...settingsForm, whatsappTemplateName: e.target.value })}
                            className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Active Plans Edit matrix */}
                    <div className="bg-black p-6 rounded border border-zinc-900 space-y-6">
                      <span className="text-xs font-bold uppercase text-amber-500 tracking-wider block border-b border-zinc-900 pb-3">3. MEMBERSHIP PLANS PRICING MATRIX</span>
                      <div className="space-y-4">
                        {settingsForm.plans.map((p, idx) => (
                          <div key={p.id} className="grid grid-cols-3 gap-6 items-center p-4 rounded bg-zinc-900 border border-zinc-800/50">
                            <span className="text-xs font-bold text-white uppercase">{p.name}</span>
                            <div>
                              <label className="block text-[9px] uppercase text-zinc-500 mb-1">Duration (Months)</label>
                              <input 
                                type="number" 
                                value={p.durationMonths}
                                onChange={(e) => {
                                  const updatedPlans = [...settingsForm.plans];
                                  updatedPlans[idx].durationMonths = parseInt(e.target.value) || 1;
                                  setSettingsForm({ ...settingsForm, plans: updatedPlans });
                                }}
                                className="w-full bg-black border border-zinc-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] uppercase text-zinc-500 mb-1">Price (₹)</label>
                              <input 
                                type="number" 
                                value={p.price}
                                onChange={(e) => {
                                  const updatedPlans = [...settingsForm.plans];
                                  updatedPlans[idx].price = parseInt(e.target.value) || 0;
                                  setSettingsForm({ ...settingsForm, plans: updatedPlans });
                                }}
                                className="w-full bg-black border border-zinc-800 rounded px-3 py-1.5 text-xs text-white focus:outline-none"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button 
                      type="submit"
                      className="px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs uppercase tracking-widest rounded shadow-md shadow-amber-500/10"
                    >
                      Save Configuration
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* MODAL 1: ADD / EDIT MEMBER */}
      {showMemberModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-zinc-950 border border-zinc-900 rounded max-w-2xl w-full p-8 max-h-[90vh] overflow-y-auto"
          >
            <h3 className="text-xl font-black uppercase text-white mb-6">
              {editingMember ? `Modify ${editingMember.id}` : "Enroll New Posture Member"}
            </h3>

            <form onSubmit={handleMemberSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Full Name *</label>
                  <input 
                    type="text" required placeholder="Rahul Sharma"
                    value={memberForm.fullName}
                    onChange={(e) => setMemberForm({ ...memberForm, fullName: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Phone Number (WhatsApp) *</label>
                  <input 
                    type="tel" required placeholder="+91 97316 77316"
                    value={memberForm.phone}
                    onChange={(e) => setMemberForm({ ...memberForm, phone: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Email Address</label>
                  <input 
                    type="email" placeholder="rahul@gmail.com"
                    value={memberForm.email}
                    onChange={(e) => setMemberForm({ ...memberForm, email: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Gender</label>
                  <select 
                    value={memberForm.gender}
                    onChange={(e) => setMemberForm({ ...memberForm, gender: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">DOB</label>
                  <input 
                    type="date"
                    value={memberForm.dob}
                    onChange={(e) => setMemberForm({ ...memberForm, dob: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Emergency Contact</label>
                  <input 
                    type="text" placeholder="Amit Sharma (+91 98765...)"
                    value={memberForm.emergencyContact}
                    onChange={(e) => setMemberForm({ ...memberForm, emergencyContact: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Residential Address</label>
                  <input 
                    type="text" placeholder="Kuempunagar, Mysuru"
                    value={memberForm.address}
                    onChange={(e) => setMemberForm({ ...memberForm, address: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  />
                </div>

                {!editingMember && (
                  <>
                    <div>
                      <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Joining Membership Plan</label>
                      <select 
                        value={memberForm.membershipPlan}
                        onChange={(e) => {
                          const p = settings?.plans.find(x => x.name === e.target.value);
                          setMemberForm({ 
                            ...memberForm, 
                            membershipPlan: e.target.value,
                            amountPaid: p?.price || 2500 
                          });
                        }}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                      >
                        {settings?.plans.map(p => (
                          <option key={p.id} value={p.name}>{p.name} (₹{p.price})</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Amount Paid (₹)</label>
                      <input 
                        type="number"
                        value={memberForm.amountPaid}
                        onChange={(e) => {
                          const paid = parseFloat(e.target.value) || 0;
                          const pName = memberForm.membershipPlan;
                          const p = settings?.plans.find(x => x.name === pName);
                          const bal = Math.max(0, (p?.price || 0) - paid);
                          setMemberForm({ 
                            ...memberForm, 
                            amountPaid: paid,
                            remainingBalance: bal,
                            paymentStatus: paid === 0 ? 'Unpaid' : bal === 0 ? 'Paid' : 'Partial'
                          });
                        }}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Joining Date</label>
                      <input 
                        type="date"
                        value={memberForm.joiningDate}
                        onChange={(e) => {
                          const j = e.target.value;
                          const p = settings?.plans.find(x => x.name === memberForm.membershipPlan);
                          const dur = p?.durationMonths || 1;
                          const d = new Date(j);
                          d.setMonth(d.getMonth() + dur);
                          setMemberForm({ 
                            ...memberForm, 
                            joiningDate: j,
                            membershipExpiryDate: d.toISOString().split('T')[0]
                          });
                        }}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Membership Expiry Date</label>
                      <input 
                        type="date"
                        value={memberForm.membershipExpiryDate}
                        onChange={(e) => setMemberForm({ ...memberForm, membershipExpiryDate: e.target.value })}
                        className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                      />
                    </div>
                  </>
                )}

                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">Diagnostic Notes / Fitness Goals</label>
                  <textarea 
                    rows={3} placeholder="Desk job, has forward neck posture..."
                    value={memberForm.notes}
                    onChange={(e) => setMemberForm({ ...memberForm, notes: e.target.value })}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                  ></textarea>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-zinc-900">
                <button 
                  type="button" 
                  onClick={() => setShowMemberModal(false)}
                  className="px-5 py-2.5 rounded text-xs uppercase font-bold text-zinc-400 hover:text-white"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-black rounded text-xs uppercase font-bold"
                >
                  Save Record
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* MODAL 2: RECORD PAYMENT */}
      {showPaymentModal && selectedMemberForPayment && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-900 rounded max-w-md w-full p-8 text-xs">
            <h3 className="text-lg font-black uppercase text-white mb-2">RECORD PAYMENT</h3>
            <span className="text-zinc-500 block mb-6">Payment Ledger for <strong>{selectedMemberForPayment.fullName}</strong> ({selectedMemberForPayment.id})</span>

            <form onSubmit={handlePaymentSubmit} className="space-y-6">
              <div>
                <label className="block text-zinc-400 uppercase mb-2">Payment Amount (₹)</label>
                <input 
                  type="number" required
                  value={paymentForm.amount}
                  onChange={(e) => setPaymentForm({ ...paymentForm, amount: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 uppercase mb-2">Dues Settlement Status</label>
                <select 
                  value={paymentForm.status}
                  onChange={(e) => setPaymentForm({ ...paymentForm, status: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                >
                  <option value="Paid">Fully Paid (Dues Cleared)</option>
                  <option value="Partial">Partial Payment</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 uppercase mb-2">Ledger Notes</label>
                <input 
                  type="text" placeholder="Cash or GPay payment recorded"
                  value={paymentForm.notes}
                  onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-zinc-900">
                <button type="button" onClick={() => setShowPaymentModal(false)} className="text-zinc-500 hover:text-white uppercase font-bold px-3">Cancel</button>
                <button type="submit" className="px-5 py-2.5 bg-amber-500 text-black rounded uppercase font-bold">Record Entry</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: RENEW MEMBERSHIP */}
      {showRenewModal && selectedMemberForRenewal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-zinc-900 rounded max-w-md w-full p-8 text-xs">
            <h3 className="text-lg font-black uppercase text-white mb-2 font-black">RENEW MEMBERSHIP PLAN</h3>
            <span className="text-zinc-500 block mb-6">Process a new cycle renewal for <strong>{selectedMemberForRenewal.fullName}</strong>.</span>

            <form onSubmit={handleRenewalSubmit} className="space-y-6">
              <div>
                <label className="block text-zinc-400 uppercase mb-2">Select Renewal Plan</label>
                <select 
                  value={renewalForm.planId}
                  onChange={(e) => {
                    const plan = settings?.plans.find(p => p.id === e.target.value);
                    setRenewalForm({ ...renewalForm, planId: e.target.value, amountPaid: (plan?.price || 2500).toString() });
                  }}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                >
                  {settings?.plans.map(p => (
                    <option key={p.id} value={p.id}>{p.name} (₹{p.price})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 uppercase mb-2">Renewal Joining Date</label>
                <input 
                  type="date" required
                  value={renewalForm.joiningDate}
                  onChange={(e) => setRenewalForm({ ...renewalForm, joiningDate: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 uppercase mb-2">Renewal Fee Paid (₹)</label>
                <input 
                  type="number" required
                  value={renewalForm.amountPaid}
                  onChange={(e) => setRenewalForm({ ...renewalForm, amountPaid: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-zinc-400 uppercase mb-2">Ledger Notes</label>
                <input 
                  type="text" placeholder="Cycle renewal processed"
                  value={renewalForm.notes}
                  onChange={(e) => setRenewalForm({ ...renewalForm, notes: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded px-4 py-3 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-zinc-900">
                <button type="button" onClick={() => setShowRenewModal(false)} className="text-zinc-500 hover:text-white uppercase font-bold px-3">Cancel</button>
                <button type="submit" className="px-5 py-2.5 bg-amber-500 text-black rounded uppercase font-bold">Process Renewal</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 4: INVOICE / RECEIPT GENERATOR */}
      {showReceipt && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white text-black max-w-md w-full p-8 font-mono rounded shadow-2xl relative">
            <button 
              onClick={() => setShowReceipt(null)}
              className="absolute top-4 right-4 bg-zinc-100 hover:bg-zinc-200 p-2 rounded text-zinc-500 hover:text-black no-print"
            >
              Close
            </button>
            
            <div className="text-center space-y-2 border-b-2 border-dashed border-zinc-300 pb-6 mb-6">
              <span className="font-extrabold text-lg block tracking-wider">THE POSTURE GYM</span>
              <span className="text-[10px] text-zinc-500 block max-w-xs mx-auto">
                Saraswathipuram, Mysuru, Karnataka 570009
              </span>
              <span className="text-[10px] text-zinc-500 block">Phone: +91 97316 77316</span>
            </div>

            <div className="space-y-3 text-xs mb-8">
              <div className="flex justify-between">
                <span>RECEIPT NO:</span>
                <span className="font-bold">{showReceipt.receiptNo}</span>
              </div>
              <div className="flex justify-between">
                <span>DATE:</span>
                <span>{showReceipt.date}</span>
              </div>
              <div className="flex justify-between">
                <span>MEMBER ID:</span>
                <span className="font-bold">{showReceipt.memberId}</span>
              </div>
              <div className="flex justify-between">
                <span>MEMBER NAME:</span>
                <span className="font-bold uppercase">{showReceipt.memberName}</span>
              </div>
            </div>

            <div className="border-t border-b border-zinc-200 py-4 mb-6 text-xs space-y-2">
              <div className="flex justify-between font-bold">
                <span>DESCRIPTION</span>
                <span>TOTAL</span>
              </div>
              <div className="flex justify-between">
                <span className="uppercase">Plan Fee: {showReceipt.plan}</span>
                <span>₹{showReceipt.amount.toLocaleString()}</span>
              </div>
            </div>

            <div className="text-right space-y-1 mb-8">
              <span className="text-[10px] text-zinc-500 block">AMOUNT RECEIVED</span>
              <span className="text-xl font-extrabold text-black">₹{showReceipt.amount.toLocaleString()}</span>
            </div>

            <div className="text-center space-y-4 pt-4 border-t border-dashed border-zinc-200">
              <span className="text-[10px] text-zinc-500 block italic">Thank you for investing in your spinal wellness!</span>
              <button 
                onClick={() => window.print()}
                className="w-full bg-zinc-900 hover:bg-zinc-800 text-white font-bold py-3 text-xs uppercase tracking-wider rounded no-print transition-all"
              >
                Print Receipt
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
