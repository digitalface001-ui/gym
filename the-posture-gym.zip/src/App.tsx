import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Shield, Eye, EyeOff, Lock, Mail, ArrowLeft, KeyRound } from 'lucide-react';
import PublicWebsite from './components/PublicWebsite';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  // Navigation mode: 'website' | 'login' | 'admin'
  const [view, setView] = useState<'website' | 'login' | 'admin'>('website');
  
  // Auth state
  const [token, setToken] = useState<string | null>(null);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  // Check for pre-existing session token in localStorage on mount
  useEffect(() => {
    const savedToken = localStorage.getItem('posture_gym_admin_token');
    if (savedToken) {
      setToken(savedToken);
      setView('admin');
    }
  }, []);

  // Admin click handlers
  const handleAdminLoginClick = () => {
    setLoginError(null);
    setView('login');
  };

  // Submit Admin Login credentials
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setAuthLoading(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });

      const data = await response.json();

      if (response.ok && data.token) {
        localStorage.setItem('posture_gym_admin_token', data.token);
        setToken(data.token);
        setView('admin');
        setLoginEmail('');
        setLoginPassword('');
      } else {
        setLoginError(data.error || 'Invalid credentials. Please verify your email and password.');
      }
    } catch (err) {
      setLoginError('Server authentication timeout. Please check your network connection.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle Log out
  const handleLogout = () => {
    localStorage.removeItem('posture_gym_admin_token');
    setToken(null);
    setView('website');
  };

  // Join click handler scrolls to membership section on website
  const handleJoinNow = (planName: string) => {
    setView('website');
    setTimeout(() => {
      const el = document.getElementById('contact');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
        // Set message field automatically with plan inquiry
        const textEl = document.querySelector('textarea') as HTMLTextAreaElement;
        if (textEl) {
          textEl.value = `I would like to join now under the "${planName}" membership plan. Please register my slot!`;
          textEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-black">
      {view === 'website' && (
        <PublicWebsite 
          onJoinNow={handleJoinNow} 
          onAdminLoginClick={handleAdminLoginClick} 
        />
      )}

      {view === 'login' && (
        <div className="min-h-screen flex items-center justify-center bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-zinc-900 via-black to-black px-4 relative">
          
          {/* Back button to public site */}
          <button 
            onClick={() => setView('website')}
            className="absolute top-6 left-6 flex items-center space-x-2 text-xs text-zinc-500 hover:text-amber-500 transition-colors uppercase font-bold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Website</span>
          </button>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="w-full max-w-md p-8 rounded bg-black border border-zinc-900 shadow-2xl relative"
          >
            {/* Top gold glow effect */}
            <div className="absolute top-0 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-amber-500 to-transparent"></div>

            <div className="text-center mb-8">
              <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-4 text-amber-500">
                <Shield className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-black text-white uppercase tracking-tight">ADMIN PORTAL LOGIN</h2>
              <p className="text-xs text-zinc-500 mt-1">Authorized posture administrator access only.</p>
            </div>

            {loginError && (
              <div className="mb-6 p-4 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs text-center">
                {loginError}
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-6">
              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-2">EMAIL ADDRESS</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-zinc-600" />
                  <input 
                    type="email" 
                    required 
                    placeholder="tejashn12@gmail.com"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded pl-10 pr-4 py-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-2">PORTAL PASSWORD</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 w-4 h-4 text-zinc-600" />
                  <input 
                    type={showPassword ? 'text' : 'password'} 
                    required 
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-zinc-900 border border-zinc-800 rounded pl-10 pr-12 py-3 text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3.5 text-zinc-600 hover:text-zinc-400"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={authLoading}
                className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-extrabold text-xs uppercase tracking-widest rounded transition-all shadow-md shadow-amber-500/10 hover:scale-[1.01]"
              >
                {authLoading ? 'Validating Token...' : 'Enter Admin Control'}
              </button>
            </form>

            {/* DEMO CREDENTIALS SHORTCUT PANEL */}
            <div className="mt-8 p-4 rounded bg-zinc-900/40 border border-zinc-900 flex items-start space-x-3 text-xs">
              <KeyRound className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white uppercase block text-[10px]">Evaluation Credentials</span>
                <span className="text-zinc-500 block mt-1">Email: <strong className="text-zinc-300">tejashn12@gmail.com</strong></span>
                <span className="text-zinc-500 block">Password: <strong className="text-zinc-300">123456</strong></span>
                <div className="mt-2 pt-2 border-t border-zinc-800/60 text-[10px] text-zinc-600">
                  Alternate: admin@theposture.com / admin123
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {view === 'admin' && token && (
        <AdminDashboard token={token} onLogout={handleLogout} />
      )}
    </div>
  );
}
